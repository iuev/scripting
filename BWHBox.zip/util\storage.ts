import { ServerProfile } from "./types";

const PROFILE_KEY = "bwhbox.profile.v1";

type StorageStatus = {
  kind: string;
  persistent: boolean;
};

function runtime(): Record<string, any> {
  return globalThis as Record<string, any>;
}

export function getStorageStatus(): StorageStatus {
  const env = runtime();

  if (typeof env.Keychain?.set === "function" && typeof env.Keychain?.get === "function") {
    return { kind: "Keychain", persistent: true };
  }

  if (typeof env.Storage?.set === "function" && typeof env.Storage?.get === "function") {
    return { kind: "Storage", persistent: true };
  }

  return { kind: "Unsupported", persistent: false };
}

export function loadServerProfile(): ServerProfile | null {
  const env = runtime();
  const raw =
    (typeof env.Keychain?.get === "function" ? env.Keychain.get(PROFILE_KEY) : null) ||
    (typeof env.Storage?.get === "function" ? env.Storage.get(PROFILE_KEY) : null);

  if (!raw) {
    return null;
  }

  if (typeof raw === "string") {
    try {
      return JSON.parse(raw) as ServerProfile;
    } catch {
      return null;
    }
  }

  return raw as ServerProfile;
}

export function saveServerProfile(profile: ServerProfile): void {
  const env = runtime();
  const raw = JSON.stringify(profile);

  if (typeof env.Keychain?.set === "function") {
    env.Keychain.set(PROFILE_KEY, raw);
    return;
  }

  if (typeof env.Storage?.set === "function") {
    env.Storage.set(PROFILE_KEY, profile);
    return;
  }

  throw new Error("Persistent storage is not available.");
}

export function clearServerProfile(): void {
  const env = runtime();

  if (typeof env.Keychain?.set === "function") {
    env.Keychain.set(PROFILE_KEY, "");
  }

  if (typeof env.Storage?.remove === "function") {
    env.Storage.remove(PROFILE_KEY);
  }
}
