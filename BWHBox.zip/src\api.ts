import { LiveServiceInfo, ServiceInfo, ServerProfile } from "./types";

const API_BASE = "https://api.64clouds.com/v1";

function buildUrl(path: string): string {
  return `${API_BASE}/${path}`;
}

function normalizeError(payload: Record<string, any>): void {
  if (Number(payload?.error ?? 1) !== 0) {
    throw new Error(payload?.message || "BWH API 返回错误");
  }
}

function toFormBody(payload: Record<string, string>): string {
  const params = new URLSearchParams();
  Object.entries(payload).forEach(([key, value]) => {
    params.set(key, value);
  });
  return params.toString();
}

async function postFormJson<T>(
  url: string,
  payload: Record<string, string>,
): Promise<T> {
  if (typeof fetch !== "function") {
    throw new Error("当前运行环境不支持 fetch 网络请求");
  }

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    },
    body: toFormBody(payload),
  });

  if (!response.ok) {
    throw new Error(`请求失败：HTTP ${response.status}`);
  }

  return (await response.json()) as T;
}

export class BwhApiClient {
  constructor(private readonly profile: ServerProfile) {}

  private async call<T extends Record<string, any>>(
    path: string,
    extraParams: Record<string, string> = {},
  ): Promise<T> {
    const payload = await postFormJson<T>(buildUrl(path), {
      veid: this.profile.veid,
      api_key: this.profile.apiKey,
      ...extraParams,
    });
    normalizeError(payload);
    return payload;
  }

  getServiceInfo(): Promise<ServiceInfo> {
    return this.call<ServiceInfo>("getServiceInfo");
  }

  getLiveServiceInfo(): Promise<LiveServiceInfo> {
    return this.call<LiveServiceInfo>("getLiveServiceInfo");
  }

  start(): Promise<Record<string, any>> {
    return this.call("start");
  }

  stop(): Promise<Record<string, any>> {
    return this.call("stop");
  }

  restart(): Promise<Record<string, any>> {
    return this.call("restart");
  }

  createSnapshot(description: string): Promise<Record<string, any>> {
    return this.call("snapshot/create", { description });
  }

  setPTR(ip: string, ptr: string): Promise<Record<string, any>> {
    return this.call("setPTR", { ip, ptr });
  }
}

export async function testServerConnection(profile: ServerProfile): Promise<ServiceInfo> {
  const client = new BwhApiClient(profile);
  return client.getServiceInfo();
}
