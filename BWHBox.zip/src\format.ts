import { LiveServiceInfo, MetricSample, ServiceInfo } from "./types";

const KB = 1024;
const MB = KB * 1024;
const GB = MB * 1024;
const TB = GB * 1024;

function clampPercent(value: number): number {
  if (Number.isNaN(value) || !Number.isFinite(value)) {
    return 0;
  }
  return Math.max(0, Math.min(100, value));
}

function toFiniteNumber(value: unknown): number | null {
  if (value === undefined || value === null) {
    return null;
  }

  const num = Number(value);
  if (!Number.isFinite(num)) {
    return null;
  }
  return num;
}

function resolveMonthlyDataMultiplier(service?: ServiceInfo | null): number {
  const multiplier = toFiniteNumber(service?.monthly_data_multiplier);
  if (multiplier === null || multiplier <= 0) {
    return 1;
  }
  return multiplier;
}

function applyBandwidthMultiplier(
  value: unknown,
  service?: ServiceInfo | null,
): number | null {
  const raw = toFiniteNumber(value);
  if (raw === null) {
    return null;
  }
  return raw * resolveMonthlyDataMultiplier(service);
}

export function formatBytes(value?: number | null): string {
  if (value === undefined || value === null || Number.isNaN(value)) {
    return "--";
  }

  if (value >= TB) {
    return `${(value / TB).toFixed(1)} TB`;
  }
  if (value >= GB) {
    return `${(value / GB).toFixed(1)} GB`;
  }
  if (value >= MB) {
    return `${(value / MB).toFixed(1)} MB`;
  }
  if (value >= KB) {
    return `${(value / KB).toFixed(1)} KB`;
  }
  return `${value} B`;
}

export function formatPercent(value?: number | null): string {
  if (value === undefined || value === null || Number.isNaN(value)) {
    return "--";
  }
  return `${clampPercent(value).toFixed(1)}%`;
}

export function formatDateTime(timestamp?: number | null): string {
  if (!timestamp) {
    return "--";
  }
  return new Date(timestamp * 1000).toLocaleString("zh-CN", {
    hour12: false,
  });
}

export function formatClock(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString("zh-CN", {
    hour12: false,
  });
}

export function parseLoadAverage(raw?: string | null): number | null {
  if (!raw) {
    return null;
  }

  // KVM live response does not provide a direct CPU percentage.
  // Use 1m load average as a proxy metric.
  const first = raw.split(/[,\s]+/).find(Boolean);
  if (!first) {
    return null;
  }

  const parsed = Number(first);
  return Number.isFinite(parsed) ? parsed : null;
}

export function resolveTrafficAllowanceBytes(service?: ServiceInfo | null): number | null {
  return applyBandwidthMultiplier(service?.plan_monthly_data, service);
}

export function resolveTrafficUsedBytes(service?: ServiceInfo | null): number | null {
  return applyBandwidthMultiplier(service?.data_counter, service);
}

export function resolveTrafficUsagePercent(service?: ServiceInfo | null): number | null {
  const monthly = resolveTrafficAllowanceBytes(service);
  const used = resolveTrafficUsedBytes(service);

  if (monthly === null || monthly <= 0) {
    return null;
  }
  if (used === null || used <= 0) {
    return 0;
  }

  return clampPercent((used / monthly) * 100);
}

export function resolveMemoryUsagePercent(
  service?: ServiceInfo | null,
  live?: LiveServiceInfo | null,
): number | null {
  const total = toFiniteNumber(service?.plan_ram);
  const availableKb = toFiniteNumber(live?.mem_available_kb);
  const available = availableKb === null ? null : availableKb * KB;

  if (total === null || total <= 0 || available === null) {
    return null;
  }

  return clampPercent(((total - available) / total) * 100);
}

export function resolveDiskUsagePercent(
  service?: ServiceInfo | null,
  live?: LiveServiceInfo | null,
): number | null {
  const used = toFiniteNumber(live?.ve_used_disk_space_b);
  const planDisk = toFiniteNumber(service?.plan_disk);
  const liveQuotaGb = toFiniteNumber(live?.ve_disk_quota_gb);
  const total =
    planDisk !== null && planDisk > 0
      ? planDisk
      : liveQuotaGb !== null && liveQuotaGb > 0
        ? liveQuotaGb * GB
        : null;

  if (total === null || used === null) {
    return null;
  }

  return clampPercent((used / total) * 100);
}

export function resolveStatusLabel(
  service?: ServiceInfo | null,
  live?: LiveServiceInfo | null,
): string {
  if (typeof live?.ve_status === "string" && live.ve_status.length > 0) {
    return live.ve_status;
  }
  if (service?.suspended) {
    return "Suspended";
  }
  return "Unknown";
}

export function buildMetricSample(
  service?: ServiceInfo | null,
  live?: LiveServiceInfo | null,
): MetricSample {
  return {
    timestamp: Date.now(),
    loadAverage: parseLoadAverage(live?.load_average),
    memoryUsagePercent: resolveMemoryUsagePercent(service, live),
    diskUsagePercent: resolveDiskUsagePercent(service, live),
    trafficUsagePercent: resolveTrafficUsagePercent(service),
  };
}

export function trimMetricHistory(history: MetricSample[]): MetricSample[] {
  return history.slice(-12);
}
