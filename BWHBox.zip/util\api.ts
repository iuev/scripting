import { fetch } from "scripting";
import { LiveServiceInfo, ServerProfile, ServiceInfo } from "./types";

const API_BASE = "https://api.64clouds.com/v1";

function buildUrl(path: string): string {
  return `${API_BASE}/${path}`;
}

function buildFormBody(payload: Record<string, string>): string {
  const params = new URLSearchParams();
  Object.entries(payload).forEach(([key, value]) => {
    params.set(key, value);
  });
  return params.toString();
}

function normalizeError(payload: Record<string, any>): void {
  if (Number(payload?.error ?? 1) !== 0) {
    throw new Error(payload?.message || "BWH API returned an error.");
  }
}

async function postJson<T>(url: string, payload: Record<string, string>): Promise<T> {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    },
    body: buildFormBody(payload),
  });

  if (!response.ok) {
    throw new Error(`Request failed: HTTP ${response.status}`);
  }

  return (await response.json()) as T;
}

export class BwhApiClient {
  constructor(private readonly profile: ServerProfile) {}

  private async call<T extends Record<string, any>>(
    path: string,
    extraParams: Record<string, string> = {},
  ): Promise<T> {
    const payload = await postJson<T>(buildUrl(path), {
      veid: this.profile.veid,
      api_key: this.profile.apiKey,
      ...extraParams,
    });
    normalizeError(payload);
    return payload;
  }

  getServiceInfo(): Promise<ServiceInfo> {
    return this.call<ServiceInfo>("getServiceInfo");
  }

  getLiveServiceInfo(): Promise<LiveServiceInfo> {
    return this.call<LiveServiceInfo>("getLiveServiceInfo");
  }

  start(): Promise<Record<string, any>> {
    return this.call("start");
  }

  stop(): Promise<Record<string, any>> {
    return this.call("stop");
  }

  restart(): Promise<Record<string, any>> {
    return this.call("restart");
  }
}

export async function testServerConnection(profile: ServerProfile): Promise<ServiceInfo> {
  const client = new BwhApiClient(profile);
  return client.getServiceInfo();
}
