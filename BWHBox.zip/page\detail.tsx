import {
  Button,
  HStack,
  List,
  Navigation,
  NavigationStack,
  ProgressView,
  Section,
  Spacer,
  Text,
  useEffect,
  useState,
} from "scripting";

import { BwhApiClient } from "../util/api";
import {
  formatBytes,
  formatClock,
  formatDateTime,
  formatPercent,
  parseLoadAverage,
  resolveDiskUsagePercent,
  resolveMemoryUsagePercent,
  resolveStatusLabel,
  resolveTrafficAllowanceBytes,
  resolveTrafficUsedBytes,
  resolveTrafficUsagePercent,
} from "../util/format";
import { LiveServiceInfo, ServerProfile, ServiceInfo } from "../util/types";

type DetailTab = "panel" | "monitor" | "settings";
type PowerAction = "stop" | "restart" | null;

export function View({ profile }: { profile: ServerProfile }) {
  const dismiss = Navigation.useDismiss();
  return (
    <NavigationStack>
      <DetailContent profile={profile} dismiss={dismiss} />
    </NavigationStack>
  );
}

function DetailContent({
  profile,
  dismiss,
}: {
  profile: ServerProfile;
  dismiss?: () => void;
}) {
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<DetailTab>("panel");
  const [serviceInfo, setServiceInfo] = useState<ServiceInfo | null>(null);
  const [liveInfo, setLiveInfo] = useState<LiveServiceInfo | null>(null);
  const [notice, setNotice] = useState("");
  const [errorText, setErrorText] = useState("");
  const [busyLabel, setBusyLabel] = useState("");
  const [lastRefreshedAt, setLastRefreshedAt] = useState<number | null>(null);
  const [pendingAction, setPendingAction] = useState<PowerAction>(null);

  const client = new BwhApiClient(profile);

  useEffect(() => {
    void refreshServiceInfo();
  }, []);

  async function refreshServiceInfo() {
    setLoading(true);
    setErrorText("");

    try {
      const info = await client.getServiceInfo();
      setServiceInfo(info);
      setLastRefreshedAt(Date.now());
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "Failed to refresh server info.");
    } finally {
      setLoading(false);
    }
  }

  async function refreshLiveInfo() {
    setBusyLabel("Refreshing monitor...");
    setErrorText("");

    try {
      const info = await client.getLiveServiceInfo();
      setLiveInfo(info);
      setLastRefreshedAt(Date.now());
      setNotice("Live monitor refreshed.");
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "Failed to refresh monitor.");
    } finally {
      setBusyLabel("");
    }
  }

  async function startServer() {
    setBusyLabel("Starting server...");
    setErrorText("");

    try {
      await client.start();
      setNotice("Start request sent.");
      await refreshServiceInfo();
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "Failed to start server.");
    } finally {
      setBusyLabel("");
    }
  }

  async function confirmPowerAction() {
    if (!pendingAction) {
      return;
    }

    setBusyLabel(pendingAction === "stop" ? "Stopping server..." : "Restarting server...");
    setErrorText("");

    try {
      if (pendingAction === "stop") {
        await client.stop();
        setNotice("Stop request sent.");
      } else {
        await client.restart();
        setNotice("Restart request sent.");
      }

      setPendingAction(null);
      await refreshServiceInfo();
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "Failed to execute power action.");
    } finally {
      setBusyLabel("");
    }
  }

  const toolbar = {
    topBarLeading: dismiss
      ? [<Button title={"Close"} systemImage={"xmark"} action={dismiss} />]
      : [],
    topBarTrailing: [
      <Button
        title={tab === "monitor" ? "Refresh Monitor" : "Refresh"}
        systemImage={"arrow.clockwise"}
        action={() => {
          if (tab === "monitor") {
            void refreshLiveInfo();
            return;
          }
          void refreshServiceInfo();
        }}
      />,
    ],
  };

  if (loading) {
    return (
      <ProgressView
        navigationTitle={profile.name || serviceInfo?.hostname || "Server Panel"}
        toolbar={toolbar}
      />
    );
  }

  const statusLabel = resolveStatusLabel(serviceInfo, liveInfo);
  const trafficAllowanceBytes = resolveTrafficAllowanceBytes(serviceInfo);
  const trafficUsedBytes = resolveTrafficUsedBytes(serviceInfo);
  const trafficUsage = resolveTrafficUsagePercent(serviceInfo);
  const memoryUsage = resolveMemoryUsagePercent(serviceInfo, liveInfo);
  const diskUsage = resolveDiskUsagePercent(serviceInfo, liveInfo);
  const loadAverage = parseLoadAverage(liveInfo?.load_average);

  return (
    <List
      navigationTitle={profile.name || serviceInfo?.hostname || "Server Panel"}
      toolbar={toolbar}
      refreshable={tab === "monitor" ? refreshLiveInfo : refreshServiceInfo}
    >
      {busyLabel ? (
        <Section>
          <Text>{busyLabel}</Text>
        </Section>
      ) : null}

      {notice ? (
        <Section>
          <Text>{notice}</Text>
        </Section>
      ) : null}

      {errorText ? (
        <Section>
          <Text>{errorText}</Text>
        </Section>
      ) : null}

      <Section title={"Tabs"}>
        <HStack>
          <Button title={"Panel"} action={() => setTab("panel")} />
          <Button title={"Monitor"} action={() => setTab("monitor")} />
          <Button title={"Settings"} action={() => setTab("settings")} />
        </HStack>
      </Section>

      {tab === "panel" ? (
        <>
          <Section title={"Overview"}>
            <KeyValueRow label={"Status"} value={statusLabel} />
            <KeyValueRow label={"Traffic Usage"} value={formatPercent(trafficUsage)} />
            <KeyValueRow
              label={"Traffic"}
              value={`${formatBytes(trafficUsedBytes)} / ${formatBytes(trafficAllowanceBytes)}`}
            />
            <KeyValueRow
              label={"Last Refresh"}
              value={lastRefreshedAt ? formatClock(lastRefreshedAt) : "--"}
            />
          </Section>

          <Section title={"Server Details"}>
            <KeyValueRow label={"Hostname"} value={serviceInfo?.hostname || "--"} />
            <KeyValueRow label={"OS"} value={serviceInfo?.os || "--"} />
            <KeyValueRow label={"VM Type"} value={serviceInfo?.vm_type || "--"} />
            <KeyValueRow label={"Location"} value={serviceInfo?.node_location || "--"} />
            <KeyValueRow label={"Node"} value={serviceInfo?.node_alias || "--"} />
            <KeyValueRow label={"IP Address"} value={serviceInfo?.ip_addresses?.join(", ") || "--"} />
            <KeyValueRow label={"Disk Quota"} value={formatBytes(serviceInfo?.plan_disk ?? null)} />
            <KeyValueRow label={"RAM"} value={formatBytes(serviceInfo?.plan_ram ?? null)} />
            <KeyValueRow label={"Traffic Allowance"} value={formatBytes(trafficAllowanceBytes)} />
            <KeyValueRow label={"Reset Time"} value={formatDateTime(serviceInfo?.data_next_reset)} />
          </Section>

          <Section title={"Power Actions"}>
            <Button
              title={"Start Server"}
              action={() => {
                void startServer();
              }}
            />
            <Button title={"Restart Server"} action={() => setPendingAction("restart")} />
            <Button title={"Stop Server"} action={() => setPendingAction("stop")} />
          </Section>

          {pendingAction ? (
            <Section title={"Confirm Action"}>
              <Text>
                {pendingAction === "stop"
                  ? "Are you sure you want to stop this server?"
                  : "Are you sure you want to restart this server?"}
              </Text>
              <Button title={"Cancel"} action={() => setPendingAction(null)} />
              <Button
                title={"Confirm"}
                action={() => {
                  void confirmPowerAction();
                }}
              />
            </Section>
          ) : null}
        </>
      ) : null}

      {tab === "monitor" ? (
        <>
          <Section title={"Live Monitor"}>
            <Button
              title={"Refresh Live Monitor"}
              action={() => {
                void refreshLiveInfo();
              }}
            />
            <KeyValueRow
              label={"Load (1m)"}
              value={loadAverage === null ? "--" : loadAverage.toFixed(2)}
            />
            <KeyValueRow label={"Memory Usage"} value={formatPercent(memoryUsage)} />
            <KeyValueRow label={"Disk Usage"} value={formatPercent(diskUsage)} />
            <KeyValueRow label={"Traffic Usage"} value={formatPercent(trafficUsage)} />
            <KeyValueRow label={"SSH Port"} value={String(liveInfo?.ssh_port ?? "--")} />
            <KeyValueRow label={"CPU Throttled"} value={liveInfo?.is_cpu_throttled ? "Yes" : "No"} />
            <KeyValueRow label={"Disk Throttled"} value={liveInfo?.is_disk_throttled ? "Yes" : "No"} />
          </Section>
        </>
      ) : null}

      {tab === "settings" ? (
        <Section title={"Settings"}>
          <Text>System, network, snapshot and migration tools will be added later.</Text>
          <KeyValueRow label={"rDNS API"} value={serviceInfo?.rdns_api_available ? "Available" : "Unavailable"} />
          <KeyValueRow label={"Datacenter"} value={serviceInfo?.node_location || "--"} />
        </Section>
      ) : null}
    </List>
  );
}

function KeyValueRow({ label, value }: { label: string; value: string }) {
  return (
    <HStack>
      <Text>{label}</Text>
      <Spacer />
      <Text>{value}</Text>
    </HStack>
  );
}
