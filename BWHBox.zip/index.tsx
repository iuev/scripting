import {
  Button,
  HStack,
  Navigation,
  NavigationStack,
  ScrollView,
  Script,
  SecureField,
  Spacer,
  Text,
  TextField,
  VStack,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "scripting";

import { BwhApiClient, testServerConnection } from "./src/api";
import {
  buildMetricSample,
  formatClock,
  formatDateTime,
  formatPercent,
  formatBytes,
  parseLoadAverage,
  resolveDiskUsagePercent,
  resolveMemoryUsagePercent,
  resolveStatusLabel,
  resolveTrafficAllowanceBytes,
  resolveTrafficUsedBytes,
  resolveTrafficUsagePercent,
  trimMetricHistory,
} from "./src/format";
import {
  clearServerProfile,
  getStorageCapability,
  loadServerProfile,
  saveServerProfile,
} from "./src/storage";
import {
  AppScreen,
  AppTab,
  LiveServiceInfo,
  MetricSample,
  PlaceholderPage,
  PowerAction,
  ServiceInfo,
  ServerProfile,
} from "./src/types";

type FormState = {
  veid: string;
  apiKey: string;
  name: string;
};

const EMPTY_FORM: FormState = {
  veid: "",
  apiKey: "",
  name: "",
};

function BwhBoxApp() {
  const taskLockRef = useRef(false);
  const [screen, setScreen] = useState<AppScreen>("home");
  const [tab, setTab] = useState<AppTab>("panel");
  const [placeholderPage, setPlaceholderPage] = useState<PlaceholderPage>("system");
  const [profile, setProfile] = useState<ServerProfile | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [serviceInfo, setServiceInfo] = useState<ServiceInfo | null>(null);
  const [liveInfo, setLiveInfo] = useState<LiveServiceInfo | null>(null);
  const [metricHistory, setMetricHistory] = useState<MetricSample[]>([]);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [notice, setNotice] = useState<string>("");
  const [errorText, setErrorText] = useState<string>("");
  const [pendingAction, setPendingAction] = useState<PowerAction | null>(null);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<number | null>(null);

  useEffect(() => {
    void bootstrap();
  }, []);

  const client = useMemo(() => {
    return profile ? new BwhApiClient(profile) : null;
  }, [profile]);

  async function bootstrap() {
    const saved = await loadServerProfile();
    if (!saved) {
      setScreen("add-server");
      return;
    }

    setProfile(saved);
    setForm(saved);
    await refreshServiceInfo(saved, true);
  }

  function patchForm(key: keyof FormState, value: string) {
    setForm((current) => ({
      ...current,
      [key]: value,
    }));
  }

  function resetFeedback() {
    setNotice("");
    setErrorText("");
  }

  async function runTask(taskKey: string, task: () => Promise<void>) {
    if (taskLockRef.current) {
      return;
    }

    taskLockRef.current = true;
    setBusyKey(taskKey);
    resetFeedback();

    try {
      await task();
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "出现未知错误");
    } finally {
      taskLockRef.current = false;
      setBusyKey(null);
    }
  }

  async function refreshServiceInfo(targetProfile?: ServerProfile, openDetail = false) {
    const nextProfile = targetProfile ?? profile;
    if (!nextProfile) {
      return;
    }

    const nextClient = new BwhApiClient(nextProfile);
    await runTask("refresh-service", async () => {
      const info = await nextClient.getServiceInfo();
      setServiceInfo(info);
      setLastRefreshedAt(Date.now());
      if (openDetail) {
        setScreen("detail");
        setTab("panel");
      }
      setNotice("基础信息已更新");
    });
  }

  async function refreshLiveInfo() {
    if (!client) {
      return;
    }

    await runTask("refresh-live", async () => {
      const live = await client.getLiveServiceInfo();
      setLiveInfo(live);
      // 监控页采用手动刷新，所以这里顺手把最近样本也收集起来，后续可直接升级成图表。
      setMetricHistory((current) =>
        trimMetricHistory([...current, buildMetricSample(serviceInfo ?? live, live)]),
      );
      setLastRefreshedAt(Date.now());
      setNotice("实时监控已刷新");
    });
  }

  async function handleTestConnection() {
    const candidate: ServerProfile = {
      veid: form.veid.trim(),
      apiKey: form.apiKey.trim(),
      name: form.name.trim(),
    };

    await runTask("test-connection", async () => {
      const info = await testServerConnection(candidate);
      setNotice(`连接成功：${info.hostname || info.node_location || candidate.veid}`);
    });
  }

  async function handleSaveServer() {
    const candidate: ServerProfile = {
      veid: form.veid.trim(),
      apiKey: form.apiKey.trim(),
      name: form.name.trim(),
    };

    if (!candidate.veid || !candidate.apiKey) {
      setErrorText("VEID 和 API Key 不能为空");
      return;
    }

    if (!storageCapability.persistent) {
      setErrorText("当前环境不支持持久化存储，无法安全保存服务器配置");
      return;
    }

    await runTask("save-server", async () => {
      const info = await testServerConnection(candidate);
      await saveServerProfile(candidate);
      setProfile(candidate);
      setForm(candidate);
      setServiceInfo(info);
      setLiveInfo(null);
      setMetricHistory([]);
      setScreen("home");
      setNotice("服务器已保存");
    });
  }

  async function handleDeleteServer() {
    await runTask("clear-server", async () => {
      await clearServerProfile();
      setProfile(null);
      setForm(EMPTY_FORM);
      setServiceInfo(null);
      setLiveInfo(null);
      setMetricHistory([]);
      setPendingAction(null);
      setScreen("add-server");
      setNotice("已清除当前服务器配置");
    });
  }

  async function confirmPowerAction() {
    if (!client || !pendingAction) {
      return;
    }

    const action = pendingAction;
    await runTask(`power-${pendingAction}`, async () => {
      if (action === "stop") {
        await client.stop();
      } else {
        await client.restart();
      }

      setPendingAction(null);
      const info = await client.getServiceInfo();
      setServiceInfo(info);
      setLastRefreshedAt(Date.now());
      setNotice(`操作成功：${action}`);
    });
  }

  async function handleStartServer() {
    if (!client) {
      return;
    }

    await runTask("power-start", async () => {
      await client.start();
      const info = await client.getServiceInfo();
      setServiceInfo(info);
      setLastRefreshedAt(Date.now());
      setNotice("操作成功：start");
    });
  }

  const displayName = profile?.name || serviceInfo?.hostname || `VEID ${profile?.veid ?? "--"}`;
  const storageCapability = getStorageCapability();
  const statusLabel = resolveStatusLabel(serviceInfo, liveInfo);
  const trafficAllowanceBytes = resolveTrafficAllowanceBytes(serviceInfo);
  const trafficUsedBytes = resolveTrafficUsedBytes(serviceInfo);
  const trafficUsage = resolveTrafficUsagePercent(serviceInfo);
  const memoryUsage = resolveMemoryUsagePercent(serviceInfo, liveInfo);
  const diskUsage = resolveDiskUsagePercent(serviceInfo, liveInfo);
  const loadAverage = parseLoadAverage(liveInfo?.load_average);

  function renderBanner() {
    if (!notice && !errorText) {
      return null;
    }

    return (
      <VStack spacing={6}>
        {notice ? <Text>{notice}</Text> : null}
        {errorText ? <Text>{errorText}</Text> : null}
      </VStack>
    );
  }

  function renderHeader(title: string, onBack?: () => void) {
    return (
      <HStack spacing={12}>
        {onBack ? <Button title="返回" action={onBack} buttonStyle="bordered" /> : <Text>BWHBox</Text>}
        <Spacer />
        <Text>{title}</Text>
      </HStack>
    );
  }

  function renderKvRow(label: string, value: string) {
    return (
      <HStack spacing={12}>
        <Text>{label}</Text>
        <Spacer />
        <Text>{value}</Text>
      </HStack>
    );
  }

  function renderServerCard() {
    if (!profile) {
      return (
        <VStack spacing={10}>
          <Text>当前还没有已连接的 BWH 服务器。</Text>
          <Text>先添加 VEID 和 API Key，后续就可以直接在这里查看和管理服务器。</Text>
          <Button
            title="添加服务器"
            action={() => setScreen("add-server")}
            buttonStyle="borderedProminent"
          />
        </VStack>
      );
    }

    return (
      <VStack spacing={12}>
        <Text>{displayName}</Text>
        {renderKvRow("VEID", profile.veid)}
        {renderKvRow("主机名", serviceInfo?.hostname || "--")}
        {renderKvRow("位置", serviceInfo?.node_location || "--")}
        {renderKvRow("套餐", serviceInfo?.plan || "--")}
        {renderKvRow("IPv4", serviceInfo?.ip_addresses?.[0] || "--")}
        {renderKvRow(
          "已用流量",
          `${formatBytes(trafficUsedBytes)} / ${formatBytes(trafficAllowanceBytes)}`,
        )}
        {renderKvRow("流量使用", formatPercent(trafficUsage))}
        <HStack spacing={12}>
          <Button
            title="打开面板"
            action={() => setScreen("detail")}
            buttonStyle="borderedProminent"
          />
          <Button title="刷新" action={() => void refreshServiceInfo()} buttonStyle="bordered" />
        </HStack>
        <HStack spacing={12}>
          <Button
            title="替换服务器"
            action={() => setScreen("add-server")}
            buttonStyle="bordered"
          />
          <Button title="清除配置" action={() => void handleDeleteServer()} buttonStyle="bordered" />
        </HStack>
      </VStack>
    );
  }

  function renderAddServer() {
    return (
      <VStack spacing={14}>
        <Text>添加 BWH 服务器</Text>
        <Text>请输入 VEID 和 API Key。首版默认只保存一台服务器。</Text>
        {!storageCapability.persistent ? (
          <Text>当前环境不支持持久化存储，暂时不能安全保存服务器配置。</Text>
        ) : null}
        <TextField
          title="VEID"
          value={form.veid}
          onChanged={(value: string) => patchForm("veid", value)}
        />
        <SecureField
          title="API Key"
          value={form.apiKey}
          onChanged={(value: string) => patchForm("apiKey", value)}
        />
        <TextField
          title="服务器名称（可选）"
          value={form.name}
          onChanged={(value: string) => patchForm("name", value)}
        />
        <Button
          title="测试连接"
          action={() => void handleTestConnection()}
          buttonStyle="bordered"
        />
        <Button
          title="保存服务器"
          action={() => void handleSaveServer()}
          buttonStyle="borderedProminent"
        />
        {profile ? <Button title="取消" action={() => setScreen("home")} buttonStyle="bordered" /> : null}
        <VStack spacing={6}>
          <Text>如何获取 API Key</Text>
          <Text>1. 登录 BandwagonHost 客户区</Text>
          <Text>2. 进入 KiwiVM Control Panel</Text>
          <Text>3. 在左侧菜单中找到 API</Text>
          <Text>4. 复制当前 VPS 的 VEID 和 API Key</Text>
        </VStack>
      </VStack>
    );
  }

  function renderTabBar() {
    return (
      <HStack spacing={12}>
        <Button
          title="面板"
          action={() => setTab("panel")}
          buttonStyle={tab === "panel" ? "borderedProminent" : "bordered"}
        />
        <Button
          title="监控"
          action={() => setTab("monitor")}
          buttonStyle={tab === "monitor" ? "borderedProminent" : "bordered"}
        />
        <Button
          title="设置"
          action={() => setTab("settings")}
          buttonStyle={tab === "settings" ? "borderedProminent" : "bordered"}
        />
      </HStack>
    );
  }

  function renderMetricSummary() {
    return (
      <VStack spacing={8}>
        {renderKvRow("运行状态", statusLabel)}
        {renderKvRow("负载（1m）", loadAverage === null ? "--" : loadAverage.toFixed(2))}
        {renderKvRow("内存使用", formatPercent(memoryUsage))}
        {renderKvRow("磁盘使用", formatPercent(diskUsage))}
        {renderKvRow("流量使用", formatPercent(trafficUsage))}
        {renderKvRow("最近刷新", lastRefreshedAt ? formatClock(lastRefreshedAt) : "--")}
      </VStack>
    );
  }

  function renderPendingAction() {
    if (!pendingAction) {
      return null;
    }

    const labelMap: Record<PowerAction, string> = {
      start: "启动",
      stop: "停止",
      restart: "重启",
    };

    return (
      <VStack spacing={8}>
        <Text>确认执行：{labelMap[pendingAction]}</Text>
        <Text>按照你的要求，停止和重启需要二次确认。</Text>
        <HStack spacing={12}>
          <Button title="取消" action={() => setPendingAction(null)} buttonStyle="bordered" />
          <Button
            title="确认执行"
            action={() => void confirmPowerAction()}
            buttonStyle="borderedProminent"
          />
        </HStack>
      </VStack>
    );
  }

  function renderPanelTab() {
    return (
      <VStack spacing={14}>
        {renderMetricSummary()}
        <VStack spacing={8}>
          <Text>服务器详情</Text>
          {renderKvRow("主机名", serviceInfo?.hostname || "--")}
          {renderKvRow("系统", serviceInfo?.os || "--")}
          {renderKvRow("虚拟化", serviceInfo?.vm_type || "--")}
          {renderKvRow("机房", serviceInfo?.node_location || "--")}
          {renderKvRow("节点", serviceInfo?.node_alias || "--")}
          {renderKvRow("IP 地址", serviceInfo?.ip_addresses?.join(", ") || "--")}
          {renderKvRow("硬盘配额", formatBytes(serviceInfo?.plan_disk ?? null))}
          {renderKvRow("内存大小", formatBytes(serviceInfo?.plan_ram ?? null))}
          {renderKvRow("套餐流量", formatBytes(trafficAllowanceBytes))}
          {renderKvRow("已用流量", formatBytes(trafficUsedBytes))}
          {renderKvRow("重置时间", formatDateTime(serviceInfo?.data_next_reset))}
        </VStack>
        <VStack spacing={8}>
          <Text>服务器操作</Text>
          <Button
            title="启动服务器"
            action={() => void handleStartServer()}
            buttonStyle="borderedProminent"
          />
          <Button
            title="重启服务器"
            action={() => setPendingAction("restart")}
            buttonStyle="bordered"
          />
          <Button
            title="停止服务器"
            action={() => setPendingAction("stop")}
            buttonStyle="bordered"
          />
        </VStack>
        {renderPendingAction()}
      </VStack>
    );
  }

  function renderMonitorTab() {
    return (
      <VStack spacing={14}>
        <Text>监控页按手动刷新拉取 getLiveServiceInfo。</Text>
        <Button
          title="刷新实时监控"
          action={() => void refreshLiveInfo()}
          buttonStyle="borderedProminent"
        />
        {renderMetricSummary()}
        <VStack spacing={8}>
          <Text>实时信息</Text>
          {renderKvRow("SSH 端口", String(liveInfo?.ssh_port ?? "--"))}
          {renderKvRow("CPU 节流", liveInfo?.is_cpu_throttled ? "是" : "否")}
          {renderKvRow("磁盘节流", liveInfo?.is_disk_throttled ? "是" : "否")}
          {renderKvRow("MAC", liveInfo?.ve_mac1 || "--")}
          {renderKvRow("Live Hostname", liveInfo?.live_hostname || "--")}
        </VStack>
        <VStack spacing={8}>
          <Text>最近 12 次采样</Text>
          {metricHistory.length === 0 ? (
            <Text>还没有采样记录，先点一次“刷新实时监控”。</Text>
          ) : (
            metricHistory
              .slice()
              .reverse()
              .map((item) => (
                <Text key={String(item.timestamp)}>
                  {formatClock(item.timestamp)} | 负载{" "}
                  {item.loadAverage === null ? "--" : item.loadAverage.toFixed(2)} | 内存{" "}
                  {formatPercent(item.memoryUsagePercent)} | 磁盘{" "}
                  {formatPercent(item.diskUsagePercent)} | 流量{" "}
                  {formatPercent(item.trafficUsagePercent)}
                </Text>
              ))
          )}
        </VStack>
      </VStack>
    );
  }

  function openPlaceholder(page: PlaceholderPage) {
    setPlaceholderPage(page);
    setScreen("placeholder");
  }

  function renderSettingsTab() {
    return (
      <VStack spacing={14}>
        <Text>设置页首版保留主入口和占位子页，便于后续继续接快照、PTR 和迁移接口。</Text>
        {renderKvRow("存储后端", storageCapability.kind)}
        {renderKvRow("持久化支持", storageCapability.persistent ? "是" : "否")}
        <Button title="系统管理" action={() => openPlaceholder("system")} buttonStyle="bordered" />
        <Button title="网络管理" action={() => openPlaceholder("network")} buttonStyle="bordered" />
        <Button title="快照管理" action={() => openPlaceholder("snapshot")} buttonStyle="bordered" />
        <Button title="迁移管理" action={() => openPlaceholder("migration")} buttonStyle="bordered" />
        <Button
          title="编辑服务器信息"
          action={() => setScreen("add-server")}
          buttonStyle="bordered"
        />
      </VStack>
    );
  }

  function renderPlaceholder() {
    const titleMap: Record<PlaceholderPage, string> = {
      system: "系统管理",
      network: "网络管理",
      snapshot: "快照管理",
      migration: "迁移管理",
    };

    return (
      <VStack spacing={12}>
        <Text>{titleMap[placeholderPage]}</Text>
        <Text>这是首版的占位详情页，页面结构已搭好，后续可以直接接入真实 API。</Text>
        {placeholderPage === "system" ? (
          <VStack spacing={6}>
            {renderKvRow("主机名", serviceInfo?.hostname || "--")}
            {renderKvRow("系统", serviceInfo?.os || "--")}
            {renderKvRow("SSH 端口", String(liveInfo?.ssh_port ?? "--"))}
          </VStack>
        ) : null}
        {placeholderPage === "network" ? (
          <VStack spacing={6}>
            {renderKvRow("主 IP", serviceInfo?.ip_addresses?.[0] || "--")}
            {renderKvRow("rDNS API", serviceInfo?.rdns_api_available ? "可用" : "不可用")}
            <Text>下一步可接：setPTR</Text>
          </VStack>
        ) : null}
        {placeholderPage === "snapshot" ? (
          <VStack spacing={6}>
            <Text>下一步可接：snapshot/create</Text>
            <Text>建议在这里增加快照列表、创建快照和通知反馈。</Text>
          </VStack>
        ) : null}
        {placeholderPage === "migration" ? (
          <VStack spacing={6}>
            {renderKvRow("当前节点", serviceInfo?.node_alias || "--")}
            {renderKvRow("当前地区", serviceInfo?.node_location || "--")}
            <Text>等待后续 API 明确后接入真实迁移操作。</Text>
          </VStack>
        ) : null}
      </VStack>
    );
  }

  function renderDetail() {
    return (
      <VStack spacing={14}>
        <Text>{displayName}</Text>
        {renderTabBar()}
        {tab === "panel" ? renderPanelTab() : null}
        {tab === "monitor" ? renderMonitorTab() : null}
        {tab === "settings" ? renderSettingsTab() : null}
      </VStack>
    );
  }

  function renderBody() {
    if (screen === "add-server") {
      return renderAddServer();
    }
    if (screen === "detail") {
      return renderDetail();
    }
    if (screen === "placeholder") {
      return renderPlaceholder();
    }
    return renderServerCard();
  }

  function currentTitle(): string {
    if (screen === "add-server") {
      return "添加服务器";
    }
    if (screen === "detail") {
      return tab === "panel" ? "仪表盘" : tab === "monitor" ? "监控" : "设置";
    }
    if (screen === "placeholder") {
      return "设置详情";
    }
    return "服务器列表";
  }

  function currentBackAction() {
    if (screen === "add-server" && profile) {
      return () => setScreen("home");
    }
    if (screen === "detail") {
      return () => setScreen("home");
    }
    if (screen === "placeholder") {
      return () => setScreen("detail");
    }
    return undefined;
  }

  return (
    <NavigationStack>
      <ScrollView>
        <VStack spacing={16}>
          {renderHeader(currentTitle(), currentBackAction())}
          {busyKey ? <Text>处理中：{busyKey}</Text> : null}
          {renderBanner()}
          {renderBody()}
        </VStack>
      </ScrollView>
    </NavigationStack>
  );
}

async function main() {
  await Navigation.present({
    element: <BwhBoxApp />,
  });
  Script.exit();
}

void main();
