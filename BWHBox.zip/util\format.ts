import { LiveServiceInfo, ServiceInfo } from "./types";

const KB = 1024;
const MB = KB * 1024;
const GB = MB * 1024;
const TB = GB * 1024;

function clampPercent(value: number): number {
  return Math.max(0, Math.min(100, value));
}

function toNumber(value: unknown): number | null {
  if (value === undefined || value === null) {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function resolveBandwidthMultiplier(service?: ServiceInfo | null): number {
  const multiplier = toNumber(service?.monthly_data_multiplier);
  if (multiplier === null || multiplier <= 0) {
    return 1;
  }
  return multiplier;
}

export function formatBytes(value?: number | null): string {
  if (value === undefined || value === null || Number.isNaN(value)) {
    return "--";
  }

  if (value >= TB) {
    return `${(value / TB).toFixed(1)} TB`;
  }
  if (value >= GB) {
    return `${(value / GB).toFixed(1)} GB`;
  }
  if (value >= MB) {
    return `${(value / MB).toFixed(1)} MB`;
  }
  if (value >= KB) {
    return `${(value / KB).toFixed(1)} KB`;
  }
  return `${value} B`;
}

export function formatPercent(value?: number | null): string {
  if (value === undefined || value === null || Number.isNaN(value)) {
    return "--";
  }
  return `${clampPercent(value).toFixed(1)}%`;
}

export function formatDateTime(timestamp?: number | null): string {
  if (!timestamp) {
    return "--";
  }
  return new Date(timestamp * 1000).toLocaleString("zh-CN", { hour12: false });
}

export function formatClock(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString("zh-CN", { hour12: false });
}

export function parseLoadAverage(raw?: string | null): number | null {
  if (!raw) {
    return null;
  }
  const first = raw.split(/[,\s]+/).find(Boolean);
  if (!first) {
    return null;
  }
  const parsed = Number(first);
  return Number.isFinite(parsed) ? parsed : null;
}

export function resolveTrafficAllowanceBytes(service?: ServiceInfo | null): number | null {
  const monthly = toNumber(service?.plan_monthly_data);
  if (monthly === null) {
    return null;
  }
  return monthly * resolveBandwidthMultiplier(service);
}

export function resolveTrafficUsedBytes(service?: ServiceInfo | null): number | null {
  const used = toNumber(service?.data_counter);
  if (used === null) {
    return null;
  }
  return used * resolveBandwidthMultiplier(service);
}

export function resolveTrafficUsagePercent(service?: ServiceInfo | null): number | null {
  const total = resolveTrafficAllowanceBytes(service);
  const used = resolveTrafficUsedBytes(service);

  if (total === null || total <= 0) {
    return null;
  }
  if (used === null || used <= 0) {
    return 0;
  }

  return clampPercent((used / total) * 100);
}

export function resolveMemoryUsagePercent(
  service?: ServiceInfo | null,
  live?: LiveServiceInfo | null,
): number | null {
  const total = toNumber(service?.plan_ram);
  const availableKb = toNumber(live?.mem_available_kb);

  if (total === null || total <= 0 || availableKb === null) {
    return null;
  }

  const available = availableKb * KB;
  return clampPercent(((total - available) / total) * 100);
}

export function resolveDiskUsagePercent(
  service?: ServiceInfo | null,
  live?: LiveServiceInfo | null,
): number | null {
  const used = toNumber(live?.ve_used_disk_space_b);
  const total = toNumber(service?.plan_disk) || (toNumber(live?.ve_disk_quota_gb) || 0) * GB;

  if (used === null || total <= 0) {
    return null;
  }

  return clampPercent((used / total) * 100);
}

export function resolveStatusLabel(
  service?: ServiceInfo | null,
  live?: LiveServiceInfo | null,
): string {
  if (typeof live?.ve_status === "string" && live.ve_status.length > 0) {
    return live.ve_status;
  }
  if (service?.suspended) {
    return "Suspended";
  }
  return "Unknown";
}
