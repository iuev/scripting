import { ServerProfile } from "./types";

const STORAGE_KEY = "bwhbox.single-server.v1";
const memoryStore = new Map<string, string>();
const NON_PERSISTENT_STORAGE_ERROR =
  "当前运行环境不支持可持久化存储，无法安全保存服务器配置";

type StorageKind =
  | "storage-api"
  | "local-storage"
  | "user-defaults"
  | "memory-fallback";

type StorageBridge = {
  kind: StorageKind;
  persistent: boolean;
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
};

function resolveBridge(): StorageBridge {
  const runtime = globalThis as Record<string, any>;

  if (runtime.Storage?.get && runtime.Storage?.set) {
    return {
      kind: "storage-api",
      persistent: true,
      getItem: async (key) => {
        const value = await Promise.resolve(runtime.Storage.get(key));
        return value ?? null;
      },
      setItem: async (key, value) => {
        await Promise.resolve(runtime.Storage.set(key, value));
      },
      removeItem: async (key) => {
        if (typeof runtime.Storage.remove === "function") {
          await Promise.resolve(runtime.Storage.remove(key));
        }
      },
    };
  }

  if (runtime.UserDefaults?.stringForKey && runtime.UserDefaults?.setValueForKey) {
    return {
      kind: "user-defaults",
      persistent: true,
      getItem: async (key) => Promise.resolve(runtime.UserDefaults.stringForKey(key)),
      setItem: async (key, value) =>
        Promise.resolve(runtime.UserDefaults.setValueForKey(value, key)).then(() => undefined),
      removeItem: async (key) => {
        if (typeof runtime.UserDefaults.removeObjectForKey === "function") {
          await Promise.resolve(runtime.UserDefaults.removeObjectForKey(key));
        }
      },
    };
  }

  if (runtime.localStorage?.getItem && runtime.localStorage?.setItem) {
    return {
      kind: "local-storage",
      persistent: true,
      getItem: async (key) => runtime.localStorage.getItem(key),
      setItem: async (key, value) => {
        runtime.localStorage.setItem(key, value);
      },
      removeItem: async (key) => {
        runtime.localStorage.removeItem(key);
      },
    };
  }

  return {
    kind: "memory-fallback",
    persistent: false,
    getItem: async (key) => memoryStore.get(key) ?? null,
    setItem: async (key, value) => {
      memoryStore.set(key, value);
    },
    removeItem: async (key) => {
      memoryStore.delete(key);
    },
  };
}

export function getStorageCapability(): { kind: StorageKind; persistent: boolean } {
  const bridge = resolveBridge();
  return {
    kind: bridge.kind,
    persistent: bridge.persistent,
  };
}

export async function loadServerProfile(): Promise<ServerProfile | null> {
  const bridge = resolveBridge();
  const raw = await bridge.getItem(STORAGE_KEY);
  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw) as ServerProfile;
  } catch {
    await bridge.removeItem(STORAGE_KEY);
    return null;
  }
}

export async function saveServerProfile(profile: ServerProfile): Promise<void> {
  const bridge = resolveBridge();
  if (!bridge.persistent) {
    throw new Error(NON_PERSISTENT_STORAGE_ERROR);
  }
  await bridge.setItem(STORAGE_KEY, JSON.stringify(profile));
}

export async function clearServerProfile(): Promise<void> {
  const bridge = resolveBridge();
  await bridge.removeItem(STORAGE_KEY);
}
