export interface ServerProfile {
  veid: string;
  apiKey: string;
  name: string;
}

export interface BwhApiResponse {
  error: number;
  message?: string;
  [key: string]: unknown;
}

export interface ServiceInfo extends BwhApiResponse {
  vm_type?: "ovz" | "kvm";
  hostname?: string;
  node_alias?: string;
  node_location?: string;
  location_ipv6_ready?: number;
  plan?: string;
  plan_disk?: number;
  plan_ram?: number;
  plan_swap?: number;
  os?: string;
  email?: string;
  plan_monthly_data?: number;
  data_counter?: number;
  monthly_data_multiplier?: number;
  data_next_reset?: number;
  ip_addresses?: string[];
  private_ip_addresses?: string[];
  rdns_api_available?: number;
  ptr?: Record<string, string>;
  suspended?: number | boolean;
}

export interface LiveServiceInfo extends ServiceInfo {
  ve_status?: string;
  ve_mac1?: string;
  ve_used_disk_space_b?: number;
  ve_disk_quota_gb?: number;
  is_cpu_throttled?: number;
  is_disk_throttled?: number;
  ssh_port?: number;
  live_hostname?: string;
  load_average?: string;
  mem_available_kb?: number;
}
