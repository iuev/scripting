import {
  Button,
  List,
  Navigation,
  NavigationStack,
  Section,
  SecureField,
  Text,
  TextField,
  useState,
} from "scripting";

import { testServerConnection } from "../util/api";
import { getStorageStatus, saveServerProfile } from "../util/storage";
import { ServerProfile } from "../util/types";

export function View({ initialProfile }: { initialProfile?: ServerProfile | null }) {
  const dismiss = Navigation.useDismiss();
  const [veid, setVeid] = useState(initialProfile?.veid || "");
  const [apiKey, setApiKey] = useState(initialProfile?.apiKey || "");
  const [name, setName] = useState(initialProfile?.name || "");
  const [notice, setNotice] = useState("");
  const [errorText, setErrorText] = useState("");
  const storageStatus = getStorageStatus();

  function buildProfile(): ServerProfile {
    return {
      veid: veid.trim(),
      apiKey: apiKey.trim(),
      name: name.trim(),
    };
  }

  async function handleTestConnection() {
    setNotice("");
    setErrorText("");

    try {
      const profile = buildProfile();
      const info = await testServerConnection(profile);
      setNotice(`Connected: ${info.hostname || info.node_location || profile.veid}`);
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "Connection test failed.");
    }
  }

  async function handleSave() {
    setNotice("");
    setErrorText("");

    try {
      const profile = buildProfile();

      if (!profile.veid || !profile.apiKey) {
        throw new Error("VEID and API Key are required.");
      }

      if (!storageStatus.persistent) {
        throw new Error("Persistent storage is not available in the current environment.");
      }

      await testServerConnection(profile);
      saveServerProfile(profile);
      dismiss();
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "Failed to save server.");
    }
  }

  const toolbar = {
    topBarLeading: [<Button title={"Close"} systemImage={"xmark"} action={dismiss} />],
  };

  return (
    <NavigationStack>
      <List navigationTitle={initialProfile ? "Edit Server" : "Add Server"} toolbar={toolbar}>
        {notice ? (
          <Section>
            <Text>{notice}</Text>
          </Section>
        ) : null}

        {errorText ? (
          <Section>
            <Text>{errorText}</Text>
          </Section>
        ) : null}

        <Section title={"Connection"}>
          <TextField title={"VEID"} value={veid} onChanged={setVeid} />
          <SecureField title={"API Key"} value={apiKey} onChanged={setApiKey} />
          <TextField title={"Server Name (Optional)"} value={name} onChanged={setName} />
        </Section>

        <Section title={"Actions"}>
          <Button
            title={"Test Connection"}
            action={() => {
              void handleTestConnection();
            }}
          />
          <Button
            title={"Save Server"}
            action={() => {
              void handleSave();
            }}
          />
        </Section>

        <Section title={"Help"}>
          <Text>1. Sign in to your BandwagonHost client area</Text>
          <Text>2. Open KiwiVM Control Panel</Text>
          <Text>3. Find the API entry in the left menu</Text>
          <Text>4. Copy the VEID and API Key for the current VPS</Text>
        </Section>
      </List>
    </NavigationStack>
  );
}
