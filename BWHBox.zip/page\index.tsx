import {
  Button,
  HStack,
  List,
  Navigation,
  NavigationStack,
  ProgressView,
  Script,
  Section,
  Spacer,
  Text,
  useEffect,
  useState,
} from "scripting";

import { View as DetailView } from "./detail";
import { View as FormView } from "./form";
import { BwhApiClient } from "../util/api";
import {
  formatBytes,
  formatPercent,
  resolveStatusLabel,
  resolveTrafficAllowanceBytes,
  resolveTrafficUsedBytes,
  resolveTrafficUsagePercent,
} from "../util/format";
import { clearServerProfile, getStorageStatus, loadServerProfile } from "../util/storage";
import { ServiceInfo, ServerProfile } from "../util/types";

export function View() {
  const dismiss = Navigation.useDismiss();
  return (
    <NavigationStack>
      <RootView dismiss={dismiss} />
    </NavigationStack>
  );
}

function RootView({ dismiss }: { dismiss?: () => void }) {
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<ServerProfile | null>(null);
  const [serviceInfo, setServiceInfo] = useState<ServiceInfo | null>(null);
  const [notice, setNotice] = useState("");
  const [errorText, setErrorText] = useState("");

  useEffect(() => {
    void loadSummary();
  }, []);

  async function loadSummary() {
    setLoading(true);
    setErrorText("");

    try {
      const nextProfile = loadServerProfile();
      setProfile(nextProfile);

      if (!nextProfile) {
        setServiceInfo(null);
        return;
      }

      const client = new BwhApiClient(nextProfile);
      const info = await client.getServiceInfo();
      setServiceInfo(info);
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "Failed to load server info.");
    } finally {
      setLoading(false);
    }
  }

  async function openForm() {
    await Navigation.present(<FormView initialProfile={profile} />);
    await loadSummary();
  }

  async function openDetail() {
    if (!profile) {
      return;
    }

    await Navigation.present(<DetailView profile={profile} />);
    await loadSummary();
  }

  function clearFeedback() {
    setNotice("");
    setErrorText("");
  }

  function removeServer() {
    clearFeedback();
    clearServerProfile();
    setNotice("Server profile cleared.");
    void loadSummary();
  }

  const toolbar = {
    topBarLeading: dismiss
      ? [<Button title={"Close"} systemImage={"xmark"} action={dismiss} />]
      : [],
    topBarTrailing: [
      <Button
        title={profile ? "Edit" : "Add"}
        systemImage={profile ? "pencil" : "plus"}
        action={() => {
          void openForm();
        }}
      />,
    ],
  };

  if (loading) {
    return <ProgressView navigationTitle={Script.name || "BWHBox"} toolbar={toolbar} />;
  }

  const storageStatus = getStorageStatus();
  const statusLabel = resolveStatusLabel(serviceInfo, null);
  const trafficAllowanceBytes = resolveTrafficAllowanceBytes(serviceInfo);
  const trafficUsedBytes = resolveTrafficUsedBytes(serviceInfo);
  const trafficUsage = resolveTrafficUsagePercent(serviceInfo);

  return (
    <List
      navigationTitle={Script.name || "BWHBox"}
      toolbar={toolbar}
      refreshable={loadSummary}
    >
      {notice ? (
        <Section>
          <Text>{notice}</Text>
        </Section>
      ) : null}

      {errorText ? (
        <Section>
          <Text>{errorText}</Text>
        </Section>
      ) : null}

      {!profile ? (
        <Section title={"No Server"}>
          <Text>No BandwagonHost VPS has been connected yet.</Text>
          <Text>Add VEID and API Key first, then you can open overview, monitor and power actions.</Text>
          <Button
            title={"Add Server"}
            action={() => {
              void openForm();
            }}
          />
        </Section>
      ) : (
        <>
          <Section title={"Summary"}>
            <KeyValueRow label={"Name"} value={profile.name || serviceInfo?.hostname || "--"} />
            <KeyValueRow label={"VEID"} value={profile.veid} />
            <KeyValueRow label={"Status"} value={statusLabel} />
            <KeyValueRow label={"Location"} value={serviceInfo?.node_location || "--"} />
            <KeyValueRow label={"Plan"} value={serviceInfo?.plan || "--"} />
            <KeyValueRow label={"IPv4"} value={serviceInfo?.ip_addresses?.[0] || "--"} />
            <KeyValueRow
              label={"Traffic"}
              value={`${formatBytes(trafficUsedBytes)} / ${formatBytes(trafficAllowanceBytes)}`}
            />
            <KeyValueRow label={"Traffic Usage"} value={formatPercent(trafficUsage)} />
          </Section>

          <Section title={"Actions"}>
            <Button
              title={"Open Panel"}
              action={() => {
                void openDetail();
              }}
            />
            <Button
              title={"Refresh"}
              action={() => {
                void loadSummary();
              }}
            />
            <Button
              title={"Edit Server"}
              action={() => {
                void openForm();
              }}
            />
            <Button title={"Clear Profile"} action={removeServer} />
          </Section>
        </>
      )}

      <Section title={"Environment"}>
        <KeyValueRow label={"Storage"} value={storageStatus.kind} />
        <KeyValueRow label={"Persistent"} value={storageStatus.persistent ? "Yes" : "No"} />
      </Section>
    </List>
  );
}

function KeyValueRow({ label, value }: { label: string; value: string }) {
  return (
    <HStack>
      <Text>{label}</Text>
      <Spacer />
      <Text>{value}</Text>
    </HStack>
  );
}
