export type AppScreen = "home" | "add-server" | "detail" | "placeholder";

export type AppTab = "panel" | "monitor" | "settings";

export type PlaceholderPage = "system" | "network" | "snapshot" | "migration";

export type PowerAction = "start" | "stop" | "restart";

export interface ServerProfile {
  veid: string;
  apiKey: string;
  name: string;
}

export interface BwhApiResponse {
  error: number;
  message?: string;
  [key: string]: unknown;
}

export interface ServiceInfo extends BwhApiResponse {
  vm_type?: "ovz" | "kvm";
  hostname?: string;
  node_alias?: string;
  node_location?: string;
  location_ipv6_ready?: number;
  plan?: string;
  plan_monthly_data?: number;
  plan_disk?: number;
  plan_ram?: number;
  plan_swap?: number;
  os?: string;
  email?: string;
  monthly_data_multiplier?: number;
  data_counter?: number;
  data_next_reset?: number;
  ip_addresses?: string[];
  private_ip_addresses?: string[];
  available_isos?: string[];
  plan_max_ipv6s?: number;
  rdns_api_available?: number;
  plan_private_network_available?: number;
  location_private_network_available?: number;
  ptr?: Record<string, string>;
  suspended?: number | boolean;
  policy_violation?: number | boolean;
  suspension_count?: number;
  total_abuse_points?: number;
  max_abuse_points?: number;
  ip_nullroutes?: Record<
    string,
    {
      nullroute_timestamp?: number;
      nullroute_duration_s?: number;
      log?: string;
    }
  >;
}

export interface LiveServiceInfo extends ServiceInfo {
  vz_status?: Record<string, unknown>;
  vz_quota?: Record<string, unknown>;
  ve_status?: string;
  ve_mac1?: string;
  ve_used_disk_space_b?: number;
  ve_disk_quota_gb?: number;
  is_cpu_throttled?: number;
  is_disk_throttled?: number;
  ssh_port?: number;
  live_hostname?: string;
  load_average?: string;
  mem_available_kb?: number;
  swap_total_kb?: number;
  swap_available_kb?: number;
  screendump_png_base64?: string;
}

export interface MetricSample {
  timestamp: number;
  loadAverage: number | null;
  memoryUsagePercent: number | null;
  diskUsagePercent: number | null;
  trafficUsagePercent: number | null;
}
