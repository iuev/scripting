import { Script, Text, Widget } from "scripting";

(async () => {
  Widget.present(<Text>{Script.name || "BWHBox"}</Text>);
})().catch((error) => {
  Widget.present(<Text>{String(error)}</Text>);
});
