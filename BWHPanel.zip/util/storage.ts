import { ServerProfile } from "./types";

const PROFILES_KEY = "bwhpanel.profiles.v1";
const LEGACY_KEYS = ["bwhbox.profile.v1", "bwhbox.single-server.v1"];

type StorageStatus = {
  kind: string;
  persistent: boolean;
};

function runtime(): Record<string, any> {
  return globalThis as Record<string, any>;
}

function readValue(key: string): unknown {
  const env = runtime();
  return (
    (typeof env.Keychain?.get === "function" ? env.Keychain.get(key) : null) ||
    (typeof env.Storage?.get === "function" ? env.Storage.get(key) : null)
  );
}

function writeValue(key: string, json: string, raw: unknown): void {
  const env = runtime();

  if (typeof env.Keychain?.set === "function") {
    env.Keychain.set(key, json);
    return;
  }

  if (typeof env.Storage?.set === "function") {
    env.Storage.set(key, raw);
    return;
  }

  throw new Error("当前环境不支持持久化存储。");
}

function parseMaybeJson(raw: unknown): unknown {
  if (typeof raw !== "string") {
    return raw;
  }

  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function normalizeTimestamp(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function normalizeProfile(raw: unknown): ServerProfile | null {
  if (!raw || typeof raw !== "object") {
    return null;
  }

  const source = raw as Record<string, unknown>;
  const veid = String(source.veid ?? "").trim();
  const apiKey = String(source.apiKey ?? "").trim();
  const name = String(source.name ?? "").trim();

  if (!veid || !apiKey) {
    return null;
  }

  const createdAt = normalizeTimestamp(source.createdAt, Date.now());
  const updatedAt = normalizeTimestamp(source.updatedAt, createdAt);
  const id = String(source.id ?? `${veid}:${createdAt}`).trim();

  return {
    id,
    veid,
    apiKey,
    name,
    createdAt,
    updatedAt,
  };
}

function normalizeProfiles(raw: unknown): ServerProfile[] {
  const source = parseMaybeJson(raw);
  const items = Array.isArray(source) ? source : [];

  return items
    .map((item) => normalizeProfile(item))
    .filter((item): item is ServerProfile => item !== null)
    .sort((left, right) => right.updatedAt - left.updatedAt);
}

function migrateLegacyProfiles(): ServerProfile[] {
  for (const key of LEGACY_KEYS) {
    const legacyRaw = parseMaybeJson(readValue(key));
    const legacyProfile = normalizeProfile(legacyRaw);
    if (!legacyProfile) {
      continue;
    }

    const migrated = [legacyProfile];
    saveServerProfiles(migrated);
    return migrated;
  }

  return [];
}

export function getStorageStatus(): StorageStatus {
  const env = runtime();

  if (typeof env.Keychain?.set === "function" && typeof env.Keychain?.get === "function") {
    return { kind: "Keychain", persistent: true };
  }

  if (typeof env.Storage?.set === "function" && typeof env.Storage?.get === "function") {
    return { kind: "Storage", persistent: true };
  }

  return { kind: "Unsupported", persistent: false };
}

export function loadServerProfiles(): ServerProfile[] {
  const profiles = normalizeProfiles(readValue(PROFILES_KEY));
  if (profiles.length > 0) {
    return profiles;
  }

  return migrateLegacyProfiles();
}

export function saveServerProfiles(profiles: ServerProfile[]): void {
  const normalized = profiles
    .map((profile) => normalizeProfile(profile))
    .filter((profile): profile is ServerProfile => profile !== null)
    .sort((left, right) => right.updatedAt - left.updatedAt);

  writeValue(PROFILES_KEY, JSON.stringify(normalized), normalized);
}

export function upsertServerProfile(profile: Partial<ServerProfile> & {
  veid: string;
  apiKey: string;
  name: string;
}): ServerProfile {
  const current = loadServerProfiles();
  const existing = profile.id
    ? current.find((item) => item.id === profile.id)
    : current.find((item) => item.veid === profile.veid.trim());
  const now = Date.now();
  const next: ServerProfile = {
    id: (existing?.id || profile.id || `${profile.veid.trim()}:${now}`).trim(),
    veid: profile.veid.trim(),
    apiKey: profile.apiKey.trim(),
    name: profile.name.trim(),
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  };

  const merged = current.filter((item) => item.id !== next.id);
  merged.unshift(next);
  saveServerProfiles(merged);
  return next;
}

export function removeServerProfile(id: string): void {
  const next = loadServerProfiles().filter((profile) => profile.id !== id);
  saveServerProfiles(next);
}
