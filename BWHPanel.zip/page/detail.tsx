import {
  AreaChart,
  Button,
  Chart,
  HStack,
  Image,
  LineChart,
  List,
  Navigation,
  NavigationStack,
  ProgressView,
  RuleLineForValueChart,
  Section,
  Spacer,
  Text,
  VStack,
  useEffect,
  useRef,
  useState,
} from "scripting";

import { BwhApiClient } from "../util/api";
import {
  formatBytes,
  formatClock,
  formatDateTime,
  formatPercent,
  parseLoadAverage,
  resolveDiskUsagePercent,
  resolveMemoryUsagePercent,
  resolveStatusLabel,
  resolveTrafficAllowanceBytes,
  resolveTrafficUsedBytes,
  resolveTrafficUsagePercent,
} from "../util/format";
import { LiveServiceInfo, ServerProfile, ServiceInfo } from "../util/types";

type DetailTab = "panel" | "monitor";
type PowerAction = "stop" | "restart" | null;

type MonitorSample = {
  capturedAt: number;
  label: string;
  loadAverage: number | null;
  memoryUsage: number | null;
  diskUsage: number | null;
  trafficUsage: number | null;
};

const MAX_MONITOR_SAMPLES = 12;
const PERCENT_WARNING_VALUE = 80;
const MONITOR_REFRESH_MS = 1000;

export function View({ profile }: { profile: ServerProfile }) {
  const dismiss = Navigation.useDismiss();
  return (
    <NavigationStack>
      <DetailContent profile={profile} dismiss={dismiss} />
    </NavigationStack>
  );
}

function DetailContent({
  profile,
  dismiss,
}: {
  profile: ServerProfile;
  dismiss?: () => void;
}) {
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<DetailTab>("panel");
  const [serviceInfo, setServiceInfo] = useState<ServiceInfo | null>(null);
  const [liveInfo, setLiveInfo] = useState<LiveServiceInfo | null>(null);
  const [notice, setNotice] = useState("");
  const [errorText, setErrorText] = useState("");
  const [busyLabel, setBusyLabel] = useState("");
  const [lastRefreshedAt, setLastRefreshedAt] = useState<number | null>(null);
  const [pendingAction, setPendingAction] = useState<PowerAction>(null);
  const [monitorHistory, setMonitorHistory] = useState<MonitorSample[]>([]);
  const refreshingLiveRef = useRef(false);

  const client = new BwhApiClient(profile);

  useEffect(() => {
    void refreshServiceInfo();
  }, []);

  useEffect(() => {
    if (tab !== "monitor") {
      return;
    }

    let disposed = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const scheduleNext = () => {
      if (disposed) {
        return;
      }
      timer = setTimeout(() => {
        void runCycle(false);
      }, MONITOR_REFRESH_MS);
    };

    const runCycle = async (showBusy: boolean) => {
      await refreshLiveInfo(showBusy);
      scheduleNext();
    };

    void runCycle(true);

    return () => {
      disposed = true;
      if (timer) {
        clearTimeout(timer);
      }
    };
  }, [tab, profile.id]);

  async function refreshServiceInfo() {
    setLoading(true);
    setErrorText("");

    try {
      const info = await client.getServiceInfo();
      setServiceInfo(info);
      setLastRefreshedAt(Date.now());
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "刷新服务器信息失败。");
    } finally {
      setLoading(false);
    }
  }

  async function refreshLiveInfo(showBusy = true) {
    if (refreshingLiveRef.current) {
      return;
    }

    refreshingLiveRef.current = true;
    if (showBusy) {
      setBusyLabel("正在刷新监控...");
    }
    setErrorText("");

    try {
      const info = await client.getLiveServiceInfo();
      const capturedAt = Date.now();
      const sample = buildMonitorSample(info, capturedAt);

      setLiveInfo(info);
      setServiceInfo(info);
      setLastRefreshedAt(capturedAt);
      setMonitorHistory((current) => appendMonitorSample(current, sample));
      if (showBusy) {
        setNotice("实时监控已刷新。");
      }
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "刷新监控失败。");
    } finally {
      if (showBusy) {
        setBusyLabel("");
      }
      refreshingLiveRef.current = false;
    }
  }

  async function startServer() {
    setBusyLabel("正在启动服务器...");
    setErrorText("");

    try {
      await client.start();
      setLiveInfo(null);
      setNotice("启动请求已发送。");
      await refreshServiceInfo();
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "启动服务器失败。");
    } finally {
      setBusyLabel("");
    }
  }

  async function confirmPowerAction() {
    if (!pendingAction) {
      return;
    }

    setBusyLabel(pendingAction === "stop" ? "正在停止服务器..." : "正在重启服务器...");
    setErrorText("");

    try {
      if (pendingAction === "stop") {
        await client.stop();
        setNotice("停止请求已发送。");
      } else {
        await client.restart();
        setNotice("重启请求已发送。");
      }

      setLiveInfo(null);
      setPendingAction(null);
      await refreshServiceInfo();
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "执行服务器操作失败。");
    } finally {
      setBusyLabel("");
    }
  }

  const toolbar = {
    topBarLeading: dismiss
      ? [<Button title={"返回"} systemImage={"chevron.left"} action={dismiss} />]
      : [],
    topBarTrailing: [
      <Button
        title={tab === "monitor" ? "刷新监控" : "刷新"}
        systemImage={"arrow.clockwise"}
        action={() => {
          if (tab === "monitor") {
            void refreshLiveInfo(true);
            return;
          }
          void refreshServiceInfo();
        }}
      />,
    ],
    bottomBar: (
      <HStack frame={{ maxWidth: "infinity" }}>
        <Spacer />
        <TabBarButton
          active={tab === "panel"}
          title={"面板"}
          systemImage={"chart.bar.xaxis"}
          action={() => setTab("panel")}
        />
        <Spacer />
        <TabBarButton
          active={tab === "monitor"}
          title={"监控"}
          systemImage={"chart.xyaxis.line"}
          action={() => setTab("monitor")}
        />
        <Spacer />
      </HStack>
    ),
  };

  if (loading) {
    return (
      <ProgressView
        navigationTitle={navigationTitle(tab)}
        toolbar={toolbar}
      />
    );
  }

  const statusLabel = resolveStatusLabel(serviceInfo, liveInfo);
  const trafficAllowanceBytes = resolveTrafficAllowanceBytes(serviceInfo);
  const trafficUsedBytes = resolveTrafficUsedBytes(serviceInfo);
  const trafficUsage = resolveTrafficUsagePercent(serviceInfo);
  const memoryUsage = resolveMemoryUsagePercent(serviceInfo, liveInfo);
  const diskUsage = resolveDiskUsagePercent(serviceInfo, liveInfo);
  const loadAverage = parseLoadAverage(liveInfo?.load_average);

  return (
    <List
      navigationTitle={navigationTitle(tab)}
      toolbar={toolbar}
      refreshable={tab === "monitor" ? () => refreshLiveInfo(true) : refreshServiceInfo}
    >
      {busyLabel ? (
        <Section>
          <Text>{busyLabel}</Text>
        </Section>
      ) : null}

      {notice ? (
        <Section>
          <Text>{notice}</Text>
        </Section>
      ) : null}

      {errorText ? (
        <Section>
          <Text>{errorText}</Text>
        </Section>
      ) : null}

      {tab === "panel" ? (
        <>
          <Section title={"概览"}>
            <KeyValueRow label={"状态"} value={statusLabel} />
            <KeyValueRow label={"流量使用"} value={formatPercent(trafficUsage)} />
            <KeyValueRow
              label={"流量"}
              value={`${formatBytes(trafficUsedBytes)} / ${formatBytes(trafficAllowanceBytes)}`}
            />
            <KeyValueRow
              label={"最近刷新"}
              value={lastRefreshedAt ? formatClock(lastRefreshedAt) : "--"}
            />
          </Section>

          <Section title={"服务器详情"}>
            <KeyValueRow label={"主机名"} value={serviceInfo?.hostname || "--"} />
            <KeyValueRow label={"系统"} value={serviceInfo?.os || "--"} />
            <KeyValueRow label={"虚拟化"} value={serviceInfo?.vm_type || "--"} />
            <KeyValueRow label={"位置"} value={serviceInfo?.node_location || "--"} />
            <KeyValueRow label={"节点"} value={serviceInfo?.node_alias || "--"} />
            <KeyValueRow label={"IP 地址"} value={serviceInfo?.ip_addresses?.join(", ") || "--"} />
            <KeyValueRow label={"硬盘配额"} value={formatBytes(serviceInfo?.plan_disk ?? null)} />
            <KeyValueRow label={"内存大小"} value={formatBytes(serviceInfo?.plan_ram ?? null)} />
            <KeyValueRow label={"套餐流量"} value={formatBytes(trafficAllowanceBytes)} />
            <KeyValueRow label={"重置时间"} value={formatDateTime(serviceInfo?.data_next_reset)} />
          </Section>

          <Section title={"服务器操作"}>
            <Button
              title={"启动服务器"}
              action={() => {
                void startServer();
              }}
            />
            <Button title={"重启服务器"} action={() => setPendingAction("restart")} />
            <Button title={"停止服务器"} action={() => setPendingAction("stop")} />
          </Section>

          {pendingAction ? (
            <Section title={"确认操作"}>
              <Text>
                {pendingAction === "stop"
                  ? "确认停止当前服务器？"
                  : "确认重启当前服务器？"}
              </Text>
              <Button title={"取消"} action={() => setPendingAction(null)} />
              <Button
                title={"确认执行"}
                action={() => {
                  void confirmPowerAction();
                }}
              />
            </Section>
          ) : null}
        </>
      ) : null}

      {tab === "monitor" ? (
        <>
          <Section title={"实时监控"}>
            <Button
              title={"立即刷新"}
              action={() => {
                void refreshLiveInfo(true);
              }}
            />
            <KeyValueRow label={"自动刷新"} value={`每 ${MONITOR_REFRESH_MS / 1000} 秒`} />
            <KeyValueRow
              label={"负载（1m）"}
              value={loadAverage === null ? "--" : loadAverage.toFixed(2)}
            />
            <KeyValueRow label={"内存使用"} value={formatPercent(memoryUsage)} />
            <KeyValueRow label={"磁盘使用"} value={formatPercent(diskUsage)} />
            <KeyValueRow label={"流量使用"} value={formatPercent(trafficUsage)} />
            <KeyValueRow label={"SSH 端口"} value={String(liveInfo?.ssh_port ?? "--")} />
            <KeyValueRow label={"CPU 节流"} value={liveInfo?.is_cpu_throttled ? "是" : "否"} />
            <KeyValueRow label={"磁盘节流"} value={liveInfo?.is_disk_throttled ? "是" : "否"} />
            <KeyValueRow
              label={"样本数量"}
              value={`${monitorHistory.length}/${MAX_MONITOR_SAMPLES}`}
            />
          </Section>

          <MonitorChartSection
            title={"负载趋势"}
            summary={`当前负载：${loadAverage === null ? "--" : loadAverage.toFixed(2)}`}
            emptyText={"打开监控页后，这里会自动累积最近几次刷新样本。"}
            samples={monitorHistory}
            getValue={(sample) => sample.loadAverage}
            formatValue={(value) => value.toFixed(2)}
            lineColor={"systemOrange"}
            areaColors={["rgba(255, 159, 10, 0.85)", "rgba(255, 159, 10, 0.12)"]}
            yUpperBound={resolveLoadChartUpperBound(monitorHistory)}
          />

          <MonitorChartSection
            title={"内存趋势"}
            summary={`当前内存使用：${formatPercent(memoryUsage)}`}
            emptyText={"当前没有可用的内存样本。"}
            samples={monitorHistory}
            getValue={(sample) => sample.memoryUsage}
            formatValue={(value) => `${value.toFixed(1)}%`}
            lineColor={"systemBlue"}
            areaColors={["rgba(10, 132, 255, 0.85)", "rgba(10, 132, 255, 0.12)"]}
            yUpperBound={100}
            warningValue={PERCENT_WARNING_VALUE}
          />

          <MonitorChartSection
            title={"磁盘趋势"}
            summary={`当前磁盘使用：${formatPercent(diskUsage)}`}
            emptyText={"当前没有可用的磁盘样本。"}
            samples={monitorHistory}
            getValue={(sample) => sample.diskUsage}
            formatValue={(value) => `${value.toFixed(1)}%`}
            lineColor={"systemGreen"}
            areaColors={["rgba(48, 209, 88, 0.85)", "rgba(48, 209, 88, 0.12)"]}
            yUpperBound={100}
            warningValue={PERCENT_WARNING_VALUE}
          />

          <Section title={"最近样本"}>
            {monitorHistory.length === 0 ? (
              <Text>暂无样本。监控页会自动刷新，也可以手动点“立即刷新”。</Text>
            ) : (
              monitorHistory
                .slice()
                .reverse()
                .slice(0, 4)
                .map((sample) => (
                  <VStack spacing={4} key={sample.capturedAt}>
                    <HStack>
                      <Text>{sample.label}</Text>
                      <Spacer />
                      <Text>
                        负载 {sample.loadAverage === null ? "--" : sample.loadAverage.toFixed(2)}
                      </Text>
                    </HStack>
                    <HStack>
                      <Text>内存 {formatPercent(sample.memoryUsage)}</Text>
                      <Spacer />
                      <Text>磁盘 {formatPercent(sample.diskUsage)}</Text>
                    </HStack>
                    <HStack>
                      <Text>流量 {formatPercent(sample.trafficUsage)}</Text>
                    </HStack>
                  </VStack>
                ))
            )}
          </Section>
        </>
      ) : null}
    </List>
  );
}

function MonitorChartSection({
  title,
  summary,
  emptyText,
  samples,
  getValue,
  formatValue,
  lineColor,
  areaColors,
  yUpperBound,
  warningValue,
}: {
  title: string;
  summary: string;
  emptyText: string;
  samples: MonitorSample[];
  getValue: (sample: MonitorSample) => number | null;
  formatValue: (value: number) => string;
  lineColor: string;
  areaColors: [string, string];
  yUpperBound: number;
  warningValue?: number;
}) {
  const marks = samples
    .map((sample) => {
      const value = getValue(sample);
      if (value === null) {
        return null;
      }

      return {
        label: sample.label,
        value,
      };
    })
    .filter((mark): mark is { label: string; value: number } => mark !== null);

  return (
    <Section title={title}>
      <Text>{summary}</Text>
      {marks.length === 0 ? (
        <Text>{emptyText}</Text>
      ) : (
        <>
          <Chart
            frame={{ maxWidth: "infinity", height: 180 }}
            chartXAxis={"visible"}
            chartYAxis={"visible"}
            chartYScale={{
              type: "linear",
              domain: {
                from: 0,
                to: yUpperBound,
              },
            }}
          >
            <AreaChart
              marks={marks.map((mark) => ({
                label: mark.label,
                value: mark.value,
                interpolationMethod: "catmullRom",
                foregroundStyle: areaColors,
              }))}
            />
            <LineChart
              marks={marks.map((mark) => ({
                label: mark.label,
                value: mark.value,
                interpolationMethod: "catmullRom",
                symbol: "circle",
                foregroundStyle: lineColor,
              }))}
            />
            {warningValue !== undefined ? (
              <RuleLineForValueChart
                marks={[
                  {
                    value: warningValue,
                    foregroundStyle: "systemRed",
                  },
                ]}
              />
            ) : null}
          </Chart>
          <KeyValueRow
            label={"当前值"}
            value={formatValue(marks[marks.length - 1].value)}
          />
          <KeyValueRow
            label={"峰值"}
            value={formatValue(resolvePeakValue(marks))}
          />
        </>
      )}
    </Section>
  );
}

function KeyValueRow({ label, value }: { label: string; value: string }) {
  return (
    <HStack>
      <Text>{label}</Text>
      <Spacer />
      <Text>{value}</Text>
    </HStack>
  );
}

function TabBarButton({
  active,
  title,
  systemImage,
  action,
}: {
  active: boolean;
  title: string;
  systemImage: string;
  action: () => void;
}) {
  const tint = active ? "orange" : "secondaryLabel";
  return (
    <Button action={action} buttonStyle={"plain"}>
      <VStack spacing={2}>
        <Image systemName={systemImage} foregroundStyle={tint} />
        <Text foregroundStyle={tint} font={"caption2"}>
          {title}
        </Text>
      </VStack>
    </Button>
  );
}

function buildMonitorSample(info: LiveServiceInfo, capturedAt: number): MonitorSample {
  return {
    capturedAt,
    label: formatClock(capturedAt),
    loadAverage: parseLoadAverage(info.load_average),
    memoryUsage: resolveMemoryUsagePercent(info, info),
    diskUsage: resolveDiskUsagePercent(info, info),
    trafficUsage: resolveTrafficUsagePercent(info),
  };
}

function appendMonitorSample(current: MonitorSample[], sample: MonitorSample): MonitorSample[] {
  const next = [...current, sample];
  if (next.length <= MAX_MONITOR_SAMPLES) {
    return next;
  }
  return next.slice(next.length - MAX_MONITOR_SAMPLES);
}

function resolveLoadChartUpperBound(samples: MonitorSample[]): number {
  const values = samples
    .map((sample) => sample.loadAverage)
    .filter((value): value is number => value !== null);

  if (values.length === 0) {
    return 2;
  }

  const peak = Math.max(...values);
  return Math.max(2, Math.ceil((peak + 0.2) * 1.25));
}

function resolvePeakValue(marks: Array<{ label: string; value: number }>): number {
  return marks.reduce((peak, mark) => Math.max(peak, mark.value), 0);
}

function navigationTitle(tab: DetailTab): string {
  if (tab === "monitor") {
    return "监控";
  }
  return "面板";
}
