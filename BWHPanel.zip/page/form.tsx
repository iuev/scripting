import {
  Button,
  List,
  Navigation,
  NavigationStack,
  Section,
  SecureField,
  Text,
  TextField,
  useState,
} from "scripting";

import { testServerConnection } from "../util/api";
import { getStorageStatus, upsertServerProfile } from "../util/storage";
import { ServerProfile } from "../util/types";

export function View({ initialProfile }: { initialProfile?: ServerProfile | null }) {
  const dismiss = Navigation.useDismiss();
  const [veid, setVeid] = useState(initialProfile?.veid || "");
  const [apiKey, setApiKey] = useState(initialProfile?.apiKey || "");
  const [name, setName] = useState(initialProfile?.name || "");
  const [notice, setNotice] = useState("");
  const [errorText, setErrorText] = useState("");
  const storageStatus = getStorageStatus();

  function buildProfile(): ServerProfile {
    return {
      id: initialProfile?.id || "",
      veid: veid.trim(),
      apiKey: apiKey.trim(),
      name: name.trim(),
      createdAt: initialProfile?.createdAt || Date.now(),
      updatedAt: initialProfile?.updatedAt || Date.now(),
    };
  }

  async function handleTestConnection() {
    setNotice("");
    setErrorText("");

    try {
      const profile = buildProfile();
      const info = await testServerConnection(profile);
      setNotice(`连接成功：${info.hostname || info.node_location || profile.veid}`);
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "测试连接失败。");
    }
  }

  async function handleSave() {
    setNotice("");
    setErrorText("");

    try {
      const profile = buildProfile();

      if (!profile.veid || !profile.apiKey) {
        throw new Error("VEID 和 API Key 不能为空。");
      }

      if (!storageStatus.persistent) {
        throw new Error("当前环境不支持持久化存储，无法保存服务器配置。");
      }

      await testServerConnection(profile);
      upsertServerProfile(profile);
      dismiss();
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "保存服务器失败。");
    }
  }

  const toolbar = {
    topBarLeading: [<Button title={"关闭"} systemImage={"xmark"} action={dismiss} />],
  };

  return (
    <NavigationStack>
      <List navigationTitle={initialProfile ? "编辑服务器" : "添加服务器"} toolbar={toolbar}>
        {notice ? (
          <Section>
            <Text>{notice}</Text>
          </Section>
        ) : null}

        {errorText ? (
          <Section>
            <Text>{errorText}</Text>
          </Section>
        ) : null}

        <Section title={"连接信息"}>
          <TextField title={"VEID"} value={veid} onChanged={setVeid} />
          <SecureField title={"API Key"} value={apiKey} onChanged={setApiKey} />
          <TextField title={"服务器名称（可选）"} value={name} onChanged={setName} />
        </Section>

        <Section title={"操作"}>
          <Button
            title={"测试连接"}
            action={() => {
              void handleTestConnection();
            }}
          />
          <Button
            title={"保存服务器"}
            action={() => {
              void handleSave();
            }}
          />
        </Section>

        <Section title={"帮助"}>
          <Text>1. 登录 BandwagonHost 客户区</Text>
          <Text>2. 进入 KiwiVM Control Panel</Text>
          <Text>3. 在左侧菜单中找到 API</Text>
          <Text>4. 复制当前 VPS 的 VEID 和 API Key</Text>
        </Section>
      </List>
    </NavigationStack>
  );
}
