import {
  Button,
  HStack,
  List,
  Navigation,
  NavigationStack,
  ProgressView,
  Script,
  Section,
  Spacer,
  Text,
  useEffect,
  useState,
} from "scripting";

import { View as DetailView } from "./detail";
import { View as FormView } from "./form";
import { BwhApiClient } from "../util/api";
import {
  formatBytes,
  formatPercent,
  resolveStatusLabel,
  resolveTrafficAllowanceBytes,
  resolveTrafficUsedBytes,
  resolveTrafficUsagePercent,
} from "../util/format";
import { getStorageStatus, loadServerProfiles, removeServerProfile } from "../util/storage";
import { ServiceInfo, ServerProfile } from "../util/types";

type ServerCard = {
  profile: ServerProfile;
  serviceInfo: ServiceInfo | null;
  errorText: string;
};

export function View() {
  const dismiss = Navigation.useDismiss();
  return (
    <NavigationStack>
      <RootView dismiss={dismiss} />
    </NavigationStack>
  );
}

function RootView({ dismiss }: { dismiss?: () => void }) {
  const [loading, setLoading] = useState(true);
  const [cards, setCards] = useState<ServerCard[]>([]);
  const [notice, setNotice] = useState("");
  const [errorText, setErrorText] = useState("");

  useEffect(() => {
    void loadSummary();
  }, []);

  async function loadSummary() {
    setLoading(true);
    setErrorText("");

    try {
      const profiles = loadServerProfiles();
      if (profiles.length === 0) {
        setCards([]);
        return;
      }

      const nextCards = await Promise.all(
        profiles.map(async (profile) => {
          try {
            const info = await new BwhApiClient(profile).getServiceInfo();
            return {
              profile,
              serviceInfo: info,
              errorText: "",
            };
          } catch (error) {
            return {
              profile,
              serviceInfo: null,
              errorText: error instanceof Error ? error.message : "加载服务器信息失败。",
            };
          }
        }),
      );

      setCards(nextCards);
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "加载服务器信息失败。");
    } finally {
      setLoading(false);
    }
  }

  async function openForm(profile?: ServerProfile) {
    await Navigation.present(<FormView initialProfile={profile || null} />);
    await loadSummary();
  }

  async function openDetail(profile: ServerProfile) {
    await Navigation.present(<DetailView profile={profile} />);
    await loadSummary();
  }

  function clearFeedback() {
    setNotice("");
    setErrorText("");
  }

  function removeServer(profile: ServerProfile) {
    clearFeedback();
    removeServerProfile(profile.id);
    setNotice(`已删除服务器：${profile.name || profile.veid}`);
    void loadSummary();
  }

  const toolbar = {
    topBarLeading: dismiss
      ? [<Button title={"关闭"} systemImage={"xmark"} action={dismiss} />]
      : [],
    topBarTrailing: [
      <Button
        title={"添加"}
        systemImage={"plus"}
        action={() => {
          void openForm();
        }}
      />,
    ],
  };

  if (loading) {
    return <ProgressView navigationTitle={Script.name || "BWHPanel"} toolbar={toolbar} />;
  }

  const storageStatus = getStorageStatus();
  const scriptVersion = String((Script as any).version || "dev");

  return (
    <List
      navigationTitle={Script.name || "BWHPanel"}
      toolbar={toolbar}
      refreshable={loadSummary}
    >
      {notice ? (
        <Section>
          <Text>{notice}</Text>
        </Section>
      ) : null}

      {errorText ? (
        <Section>
          <Text>{errorText}</Text>
        </Section>
      ) : null}

      {cards.length === 0 ? (
        <Section title={"未连接服务器"}>
          <Text>当前还没有已连接的搬瓦工 VPS。</Text>
          <Text>现在已经支持多服务器管理，你可以连续添加多台服务器。</Text>
          <Button
            title={"添加服务器"}
            action={() => {
              void openForm();
            }}
          />
        </Section>
      ) : (
        <>
          <Section title={"服务器数量"}>
            <KeyValueRow label={"已保存"} value={`${cards.length} 台`} />
          </Section>

          {cards.map((card) => {
            const statusLabel = resolveStatusLabel(card.serviceInfo, null);
            const trafficAllowanceBytes = resolveTrafficAllowanceBytes(card.serviceInfo);
            const trafficUsedBytes = resolveTrafficUsedBytes(card.serviceInfo);
            const trafficUsage = resolveTrafficUsagePercent(card.serviceInfo);

            return (
              <Section
                key={card.profile.id}
                title={card.profile.name || card.serviceInfo?.hostname || card.profile.veid}
              >
                <KeyValueRow label={"VEID"} value={card.profile.veid} />
                <KeyValueRow label={"状态"} value={statusLabel} />
                <KeyValueRow label={"位置"} value={card.serviceInfo?.node_location || "--"} />
                <KeyValueRow label={"套餐"} value={card.serviceInfo?.plan || "--"} />
                <KeyValueRow label={"IPv4"} value={card.serviceInfo?.ip_addresses?.[0] || "--"} />
                <KeyValueRow
                  label={"流量"}
                  value={`${formatBytes(trafficUsedBytes)} / ${formatBytes(trafficAllowanceBytes)}`}
                />
                <KeyValueRow label={"流量使用"} value={formatPercent(trafficUsage)} />
                {card.errorText ? <Text>{card.errorText}</Text> : null}
                <Button
                  title={"打开面板"}
                  action={() => {
                    void openDetail(card.profile);
                  }}
                />
                <Button
                  title={"编辑服务器"}
                  action={() => {
                    void openForm(card.profile);
                  }}
                />
                <Button title={"删除服务器"} action={() => removeServer(card.profile)} />
              </Section>
            );
          })}
        </>
      )}

      <Section title={"环境状态"}>
        <KeyValueRow label={"版本"} value={scriptVersion} />
        <KeyValueRow label={"存储后端"} value={storageKindLabel(storageStatus.kind)} />
        <KeyValueRow label={"持久化支持"} value={storageStatus.persistent ? "是" : "否"} />
      </Section>
    </List>
  );
}

function KeyValueRow({ label, value }: { label: string; value: string }) {
  return (
    <HStack>
      <Text>{label}</Text>
      <Spacer />
      <Text>{value}</Text>
    </HStack>
  );
}

function storageKindLabel(kind: string): string {
  if (kind === "Keychain") {
    return "钥匙串";
  }
  if (kind === "Storage") {
    return "存储";
  }
  return "不支持";
}
