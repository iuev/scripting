import { Script, Text, Widget } from "scripting";

(async () => {
  Widget.present(<Text>{Script.name || "BWHPanel"}</Text>);
})().catch((error) => {
  Widget.present(<Text>{String(error)}</Text>);
});
