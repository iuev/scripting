import {
  Button,
  HStack,
  Image,
  Script,
  Spacer,
  Text,
  VStack,
  Widget,
} from "scripting";

import { ReloadIntent } from "./app_intents";
import { BwhApiClient } from "./util/api";
import {
  formatBytes,
  formatClock,
  formatPercent,
  parseLoadAverage,
  resolveDiskTotalBytes,
  resolveDiskUsagePercent,
  resolveDiskUsedBytes,
  resolveMemoryTotalBytes,
  resolveMemoryUsagePercent,
  resolveMemoryUsedBytes,
  resolveTrafficAllowanceBytes,
  resolveTrafficUsagePercent,
  resolveTrafficUsedBytes,
} from "./util/format";
import { loadServerProfiles } from "./util/storage";
import { LiveServiceInfo, ServerProfile } from "./util/types";

const WIDGET_REFRESH_MS = 1000;

type MetricCardData = {
  title: string;
  systemImage: string;
  accentColor: string;
  value: string;
  detail: string;
};

type WidgetSnapshot = {
  profile: ServerProfile;
  liveInfo: LiveServiceInfo;
  cards: MetricCardData[];
  refreshedAt: number;
};

function resolveWidgetParameter(): string {
  const parameter =
    String((Widget as Record<string, unknown>).parameter ?? (Script as Record<string, unknown>).widgetParameter ?? "")
      .trim();
  return parameter;
}

function resolveProfile(): ServerProfile | null {
  const profiles = loadServerProfiles();
  if (profiles.length === 0) {
    return null;
  }

  const parameter = resolveWidgetParameter();
  if (!parameter) {
    return profiles[0];
  }

  return (
    profiles.find((profile) =>
      profile.id === parameter ||
      profile.veid === parameter ||
      profile.name === parameter,
    ) || profiles[0]
  );
}

function buildCards(liveInfo: LiveServiceInfo): MetricCardData[] {
  const loadAverage = parseLoadAverage(liveInfo.load_average);
  const memoryUsed = resolveMemoryUsedBytes(liveInfo, liveInfo);
  const memoryTotal = resolveMemoryTotalBytes(liveInfo);
  const memoryUsage = resolveMemoryUsagePercent(liveInfo, liveInfo);
  const diskUsed = resolveDiskUsedBytes(liveInfo, liveInfo);
  const diskTotal = resolveDiskTotalBytes(liveInfo, liveInfo);
  const diskUsage = resolveDiskUsagePercent(liveInfo, liveInfo);
  const trafficUsed = resolveTrafficUsedBytes(liveInfo);
  const trafficTotal = resolveTrafficAllowanceBytes(liveInfo);
  const trafficUsage = resolveTrafficUsagePercent(liveInfo);

  return [
    {
      title: "CPU",
      systemImage: "cpu",
      accentColor: "#4A90E2",
      value: loadAverage === null ? "--" : loadAverage.toFixed(2),
      detail: "1m load",
    },
    {
      title: "内存",
      systemImage: "memorychip",
      accentColor: "#34C759",
      value: formatPercent(memoryUsage),
      detail: `${formatBytes(memoryUsed)} / ${formatBytes(memoryTotal)}`,
    },
    {
      title: "硬盘",
      systemImage: "internaldrive",
      accentColor: "#FF9F0A",
      value: formatPercent(diskUsage),
      detail: `${formatBytes(diskUsed)} / ${formatBytes(diskTotal)}`,
    },
    {
      title: "流量",
      systemImage: "arrow.left.arrow.right",
      accentColor: "#AF52DE",
      value: formatPercent(trafficUsage),
      detail: `${formatBytes(trafficUsed)} / ${formatBytes(trafficTotal)}`,
    },
  ];
}

async function buildSnapshot(): Promise<WidgetSnapshot> {
  const profile = resolveProfile();
  if (!profile) {
    throw new Error("请先在应用里添加服务器。");
  }

  const liveInfo = await new BwhApiClient(profile).getLiveServiceInfo();
  return {
    profile,
    liveInfo,
    cards: buildCards(liveInfo),
    refreshedAt: Date.now(),
  };
}

function renderMetricCard(card: MetricCardData) {
  return (
    <VStack
      spacing={8}
      frame={{ maxWidth: "infinity", minHeight: 78 }}
      padding={12}
      widgetBackground={{
        style: {
          light: "rgba(255,255,255,0.96)",
          dark: "rgba(34,34,36,0.92)",
        },
        shape: {
          type: "rect",
          cornerRadius: 16,
          style: "continuous",
        },
      }}
    >
      <HStack>
        <Image systemName={card.systemImage} foregroundStyle={card.accentColor} />
        <Text font={"caption2"} foregroundStyle={"secondaryLabel"}>
          {card.title}
        </Text>
        <Spacer />
        <Text font={"headline"} foregroundStyle={card.accentColor}>
          {card.value}
        </Text>
      </HStack>

      <VStack spacing={4}>
        <Text font={"caption2"} foregroundStyle={"tertiaryLabel"}>
          使用情况
        </Text>
        <Text font={"caption2"} foregroundStyle={"secondaryLabel"}>
          {card.detail}
        </Text>
      </VStack>
    </VStack>
  );
}

function renderMediumWidget(snapshot: WidgetSnapshot) {
  return (
    <Button intent={ReloadIntent(undefined)} buttonStyle={"plain"}>
      <VStack
        spacing={10}
        padding={12}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        widgetBackground={{
          style: {
            light: "rgba(245,245,247,1)",
            dark: "rgba(20,20,22,1)",
          },
        }}
      >
        <HStack>
          <VStack spacing={2}>
            <Text font={"headline"}>{snapshot.profile.name || snapshot.liveInfo.hostname || snapshot.profile.veid}</Text>
            <Text font={"caption2"} foregroundStyle={"secondaryLabel"}>
              更新于 {formatClock(snapshot.refreshedAt)}
            </Text>
          </VStack>
          <Spacer />
          <Text font={"caption2"} foregroundStyle={"secondaryLabel"}>
            点击刷新
          </Text>
        </HStack>

        <HStack spacing={10}>
          {renderMetricCard(snapshot.cards[0])}
          {renderMetricCard(snapshot.cards[1])}
        </HStack>
        <HStack spacing={10}>
          {renderMetricCard(snapshot.cards[2])}
          {renderMetricCard(snapshot.cards[3])}
        </HStack>
      </VStack>
    </Button>
  );
}

function renderSmallWidget(snapshot: WidgetSnapshot) {
  return (
    <Button intent={ReloadIntent(undefined)} buttonStyle={"plain"}>
      <VStack
        spacing={8}
        padding={12}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        widgetBackground={{
          style: {
            light: "rgba(245,245,247,1)",
            dark: "rgba(20,20,22,1)",
          },
        }}
      >
        <Text font={"headline"}>{snapshot.profile.name || snapshot.profile.veid}</Text>
        {snapshot.cards.map((card) => (
          <HStack key={card.title}>
            <Text font={"caption2"}>{card.title}</Text>
            <Spacer />
            <Text font={"caption2"} foregroundStyle={card.accentColor}>
              {card.value}
            </Text>
          </HStack>
        ))}
        <Text font={"caption2"} foregroundStyle={"secondaryLabel"}>
          {formatClock(snapshot.refreshedAt)}
        </Text>
      </VStack>
    </Button>
  );
}

function renderAccessoryWidget(snapshot: WidgetSnapshot) {
  return (
    <Button intent={ReloadIntent(undefined)} buttonStyle={"plain"}>
      <VStack spacing={4}>
        <Text font={"caption2"}>{snapshot.profile.name || snapshot.profile.veid}</Text>
        <Text font={"headline"}>{snapshot.cards[0].value}</Text>
        <Text font={"caption2"} foregroundStyle={"secondaryLabel"}>
          CPU load
        </Text>
      </VStack>
    </Button>
  );
}

function widgetReloadPolicy() {
  return {
    policy: "after" as const,
    date: new Date(Date.now() + WIDGET_REFRESH_MS),
  };
}

(async () => {
  const snapshot = await buildSnapshot();

  switch (Widget.family) {
    case "systemMedium":
    case "systemLarge":
    case "systemExtraLarge":
      Widget.present(renderMediumWidget(snapshot), widgetReloadPolicy());
      break;
    case "systemSmall":
      Widget.present(renderSmallWidget(snapshot), widgetReloadPolicy());
      break;
    case "accessoryCircular":
    case "accessoryRectangular":
      Widget.present(renderAccessoryWidget(snapshot), widgetReloadPolicy());
      break;
    default:
      Widget.present(renderMediumWidget(snapshot), widgetReloadPolicy());
      break;
  }
})().catch((error) => {
  Widget.present(<Text>{String(error)}</Text>);
}).finally(Script.exit);
