import {
  Button,
  HStack,
  Image,
  ProgressView,
  Script,
  Spacer,
  Text,
  VStack,
  Widget,
} from "scripting";

import { ReloadIntent } from "./app_intents";
import { BwhApiClient } from "./util/api";
import {
  formatBytes,
  formatClock,
  formatPercent,
  parseLoadAverage,
  resolveDiskTotalBytes,
  resolveDiskUsagePercent,
  resolveDiskUsedBytes,
  resolveMemoryTotalBytes,
  resolveMemoryUsagePercent,
  resolveMemoryUsedBytes,
  resolveTrafficAllowanceBytes,
  resolveTrafficUsagePercent,
  resolveTrafficUsedBytes,
} from "./util/format";
import { loadServerProfiles } from "./util/storage";
import { LiveServiceInfo, ServerProfile } from "./util/types";

const WIDGET_REFRESH_MS = 1000;

type MetricTone = "systemGreen" | "systemBlue" | "systemOrange" | "systemPink";

type MetricRow = {
  key: string;
  title: string;
  systemImage: string;
  tone: MetricTone;
  valueText: string;
  detailText: string;
  percent: number | null;
};

type WidgetSnapshot = {
  profile: ServerProfile;
  liveInfo: LiveServiceInfo;
  rows: MetricRow[];
  refreshedAt: number;
};

function resolveWidgetParameter(): string {
  return String(
    (Widget as Record<string, unknown>).parameter ??
      (Script as Record<string, unknown>).widgetParameter ??
      "",
  ).trim();
}

function resolveProfile(): ServerProfile | null {
  const profiles = loadServerProfiles();
  if (profiles.length === 0) {
    return null;
  }

  const parameter = resolveWidgetParameter();
  if (!parameter) {
    return profiles[0];
  }

  return (
    profiles.find((profile) =>
      profile.id === parameter ||
      profile.veid === parameter ||
      profile.name === parameter,
    ) || profiles[0]
  );
}

function clampPercent(value: number | null): number {
  if (value === null || Number.isNaN(value)) {
    return 0;
  }
  return Math.max(0, Math.min(100, value));
}

function buildRows(liveInfo: LiveServiceInfo): MetricRow[] {
  const loadAverage = parseLoadAverage(liveInfo.load_average);
  const memoryUsed = resolveMemoryUsedBytes(liveInfo, liveInfo);
  const memoryTotal = resolveMemoryTotalBytes(liveInfo);
  const memoryUsage = resolveMemoryUsagePercent(liveInfo, liveInfo);
  const diskUsed = resolveDiskUsedBytes(liveInfo, liveInfo);
  const diskTotal = resolveDiskTotalBytes(liveInfo, liveInfo);
  const diskUsage = resolveDiskUsagePercent(liveInfo, liveInfo);
  const trafficUsed = resolveTrafficUsedBytes(liveInfo);
  const trafficTotal = resolveTrafficAllowanceBytes(liveInfo);
  const trafficUsage = resolveTrafficUsagePercent(liveInfo);

  return [
    {
      key: "cpu",
      title: "CPU",
      systemImage: "cpu",
      tone: "systemGreen",
      valueText: loadAverage === null ? "--" : loadAverage.toFixed(2),
      detailText: "1m load",
      percent: loadAverage === null ? null : clampPercent(loadAverage * 100),
    },
    {
      key: "mem",
      title: "MEM",
      systemImage: "memorychip",
      tone: "systemOrange",
      valueText: formatPercent(memoryUsage),
      detailText: `${formatBytes(memoryUsed)} / ${formatBytes(memoryTotal)}`,
      percent: memoryUsage,
    },
    {
      key: "dsk",
      title: "DSK",
      systemImage: "internaldrive",
      tone: "systemGreen",
      valueText: formatPercent(diskUsage),
      detailText: `${formatBytes(diskUsed)} / ${formatBytes(diskTotal)}`,
      percent: diskUsage,
    },
    {
      key: "net",
      title: "NET",
      systemImage: "arrow.left.arrow.right",
      tone: "systemPink",
      valueText: formatPercent(trafficUsage),
      detailText: `${formatBytes(trafficUsed)} / ${formatBytes(trafficTotal)}`,
      percent: trafficUsage,
    },
  ];
}

async function buildSnapshot(): Promise<WidgetSnapshot> {
  const profile = resolveProfile();
  if (!profile) {
    throw new Error("请先在应用里添加服务器。");
  }

  const liveInfo = await new BwhApiClient(profile).getLiveServiceInfo();
  return {
    profile,
    liveInfo,
    rows: buildRows(liveInfo),
    refreshedAt: Date.now(),
  };
}

function widgetReloadPolicy() {
  return {
    policy: "after" as const,
    date: new Date(Date.now() + WIDGET_REFRESH_MS),
  };
}

function panelBackground() {
  return {
    style: "rgba(18,21,29,0.96)",
    shape: {
      type: "rect",
      cornerRadius: 26,
      style: "continuous",
    },
  } as any;
}

function rowBackground() {
  return {
    style: "rgba(255,255,255,0.04)",
    shape: {
      type: "rect",
      cornerRadius: 14,
      style: "continuous",
    },
  } as any;
}

function renderRow(row: MetricRow) {
  return (
    <VStack
      key={row.key}
      spacing={6}
      padding={10}
      background={rowBackground()}
    >
      <HStack>
        <HStack spacing={6}>
          <Image
            systemName={row.systemImage}
            foregroundStyle={row.tone as any}
            widgetAccentedRenderingMode={"fullColor"}
          />
          <Text font={"headline"} foregroundStyle={"white"}>
            {row.title}
          </Text>
        </HStack>
        <Spacer />
        <Text font={"headline"} foregroundStyle={row.tone as any}>
          {row.valueText}
        </Text>
      </HStack>

      <ProgressView
        value={clampPercent(row.percent)}
        total={100}
        progressViewStyle={"linear"}
        tint={row.tone as any}
      />

      <HStack>
        <Text font={"caption3"} foregroundStyle={"rgba(255,255,255,0.60)"}>
          {row.detailText}
        </Text>
      </HStack>
    </VStack>
  );
}

function renderMediumCompactRow(row: MetricRow) {
  return (
    <VStack key={row.key} spacing={3}>
      <HStack>
        <HStack spacing={6}>
          <Image
            systemName={row.systemImage}
            foregroundStyle={row.tone as any}
            widgetAccentedRenderingMode={"fullColor"}
          />
          <Text font={"body"} foregroundStyle={"white"}>
            {row.title}
          </Text>
          <Text font={"body"} foregroundStyle={row.tone as any}>
            {row.valueText}
          </Text>
        </HStack>
        <Spacer />
        <Text font={"caption3"} foregroundStyle={"rgba(255,255,255,0.60)"}>
          {row.detailText}
        </Text>
      </HStack>

      <ProgressView
        value={clampPercent(row.percent)}
        total={100}
        progressViewStyle={"linear"}
        tint={row.tone as any}
      />
    </VStack>
  );
}

function renderLargeWidget(snapshot: WidgetSnapshot) {
  return (
    <Button intent={ReloadIntent(undefined)} buttonStyle={"plain"}>
      <VStack
        spacing={10}
        padding={14}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        background={panelBackground()}
        preferredColorScheme={"dark"}
      >
        <HStack>
          <HStack spacing={8}>
            <Image
              systemName={"server.rack"}
              foregroundStyle={"systemGreen"}
              widgetAccentedRenderingMode={"fullColor"}
            />
            <Text font={"title3"} foregroundStyle={"white"}>
              {snapshot.profile.name || snapshot.liveInfo.hostname || snapshot.profile.veid}
            </Text>
          </HStack>
          <Spacer />
          <Text font={"caption3"} foregroundStyle={"rgba(255,255,255,0.65)"}>
            {formatClock(snapshot.refreshedAt)}
          </Text>
        </HStack>

        {snapshot.rows.map((row) => renderRow(row))}
      </VStack>
    </Button>
  );
}

function renderMediumWidget(snapshot: WidgetSnapshot) {
  return (
    <Button intent={ReloadIntent(undefined)} buttonStyle={"plain"}>
      <VStack
        spacing={8}
        padding={12}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        background={panelBackground()}
        preferredColorScheme={"dark"}
      >
        <HStack>
          <HStack spacing={8}>
            <Image
              systemName={"server.rack"}
              foregroundStyle={"systemGreen"}
              widgetAccentedRenderingMode={"fullColor"}
            />
            <Text font={"title3"} foregroundStyle={"white"}>
              {snapshot.profile.name || snapshot.liveInfo.hostname || snapshot.profile.veid}
            </Text>
          </HStack>
          <Spacer />
          <Text font={"caption3"} foregroundStyle={"rgba(255,255,255,0.65)"}>
            {formatClock(snapshot.refreshedAt)}
          </Text>
        </HStack>

        {snapshot.rows.map((row) => renderMediumCompactRow(row))}
      </VStack>
    </Button>
  );
}

function renderSmallWidget(snapshot: WidgetSnapshot) {
  return (
    <Button intent={ReloadIntent(undefined)} buttonStyle={"plain"}>
      <VStack
        spacing={8}
        padding={12}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        background={panelBackground()}
        preferredColorScheme={"dark"}
      >
        <Text font={"headline"} foregroundStyle={"white"}>
          {snapshot.profile.name || snapshot.profile.veid}
        </Text>

        {snapshot.rows.slice(0, 3).map((row) => (
          <VStack key={row.key} spacing={4}>
            <HStack>
              <Text font={"caption2"} foregroundStyle={"white"}>
                {row.title}
              </Text>
              <Spacer />
              <Text font={"caption2"} foregroundStyle={row.tone as any}>
                {row.valueText}
              </Text>
            </HStack>
            <ProgressView
              value={clampPercent(row.percent)}
              total={100}
              progressViewStyle={"linear"}
              tint={row.tone as any}
            />
          </VStack>
        ))}

        <Text font={"caption3"} foregroundStyle={"rgba(255,255,255,0.65)"}>
          更新于 {formatClock(snapshot.refreshedAt)}
        </Text>
      </VStack>
    </Button>
  );
}

function renderAccessoryWidget(snapshot: WidgetSnapshot) {
  return (
    <Button intent={ReloadIntent(undefined)} buttonStyle={"plain"}>
      <VStack spacing={4}>
        <Text font={"caption3"} foregroundStyle={"rgba(255,255,255,0.72)"}>
          {snapshot.profile.name || snapshot.profile.veid}
        </Text>
        <Text font={"headline"} foregroundStyle={"white"}>
          {snapshot.rows[0].valueText}
        </Text>
        <Text font={"caption3"} foregroundStyle={"rgba(255,255,255,0.60)"}>
          CPU load
        </Text>
      </VStack>
    </Button>
  );
}

(async () => {
  const snapshot = await buildSnapshot();

  switch (Widget.family) {
    case "systemMedium":
      Widget.present(renderMediumWidget(snapshot), widgetReloadPolicy());
      break;
    case "systemLarge":
    case "systemExtraLarge":
      Widget.present(renderLargeWidget(snapshot), widgetReloadPolicy());
      break;
    case "systemSmall":
      Widget.present(renderSmallWidget(snapshot), widgetReloadPolicy());
      break;
    case "accessoryCircular":
    case "accessoryRectangular":
      Widget.present(renderAccessoryWidget(snapshot), widgetReloadPolicy());
      break;
    default:
      Widget.present(renderMediumWidget(snapshot), widgetReloadPolicy());
      break;
  }
})().catch((error) => {
  Widget.present(<Text>{String(error)}</Text>);
}).finally(Script.exit);
